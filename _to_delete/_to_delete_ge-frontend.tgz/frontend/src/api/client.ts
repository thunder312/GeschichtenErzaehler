import type {
  UebersetzenFortsetzbar,
  FuelltextVorschau,
  UebersetzenStatus,
  AnalyseEintrag,
  AnalysatorStatus,
  AutomatikFortsetzenVorschau,
  AutomatikStatus,
  AutomatikVerlaufEintrag,
  Befund,
  BefundeAntwort,
  Benutzer,
  BenutzerAnlegenEingabe,
  BenutzerEintrag,
  BildModell,
  CoverLogAntwort,
  Einstellungen,
  EpocheErstellenAntwort,
  EpocheKurz,
  EpocheUmbenennenAntwort,
  EpocheVorschlagAntwort,
  FundusFigur,
  FundusFigurenAntwort,
  FundusImportAntwort,
  FundusProjektAntwort,
  HostContainerInfo,
  HostStatus,
  KiStartStatus,
  KiGeruestRandbedingungen,
  KiGeruestStatus,
  LoginEingabe,
  OllamaModellInfo,
  Ort,
  OrteAntwort,
  PersonaModell,
  ProjektBereinigenAntwort,
  ProjektZuruecksetzenAntwort,
  ProjektDetail,
  ProjektKurz,
  RechtschreibAntwort,
  SSHTestErgebnis,
  SyncPartner,
  SyncProjektStatus,
  SyncZeile,
  SSHZiel,
  SSHZielEingabe,
  WissenEintrag,
  WissenNaechstesAntwort,
} from "./types";

/** Fehler mit HTTP-Status und (falls vorhanden) strukturiertem `detail`.
 * `message` bleibt die menschenlesbare Meldung, damit bestehende
 * `e instanceof Error ? e.message : ...`-Stellen unveraendert funktionieren.
 * Strukturierte Faelle (z.B. das 409 "bildki_aus_waehrend_schreiben" aus
 * cover/generieren) lesen `detail`. */
export class ApiError extends Error {
  status: number;
  detail: unknown;
  constructor(message: string, status: number, detail: unknown) {
    super(message);
    this.name = "ApiError";
    this.status = status;
    this.detail = detail;
  }
}

async function anfrage<T>(pfad: string, init?: RequestInit): Promise<T> {
  const antwort = await fetch(pfad, {
    headers: { "Content-Type": "application/json" },
    credentials: "same-origin",
    ...init,
  });
  if (!antwort.ok) {
    let detail: unknown = antwort.statusText;
    try {
      const body = await antwort.json();
      detail = body.detail ?? detail;
    } catch {
      // Antwort war kein JSON - Statustext reicht als Fehlermeldung.
    }
    const meldung =
      typeof detail === "string"
        ? detail
        : (detail && typeof detail === "object" && "text" in detail
            ? String((detail as { text: unknown }).text)
            : detail && typeof detail === "object" && "nachricht" in detail
              ? String((detail as { nachricht: unknown }).nachricht)
              : antwort.statusText);
    throw new ApiError(meldung, antwort.status, detail);
  }
  if (antwort.status === 204) {
    return undefined as T;
  }
  const contentType = antwort.headers.get("content-type") ?? "";
  if (contentType.includes("application/json")) {
    return (await antwort.json()) as T;
  }
  return (await antwort.text()) as unknown as T;
}

function sshQuery(sshZielId?: string | null): string {
  return sshZielId ? `?ssh_ziel_id=${encodeURIComponent(sshZielId)}` : "";
}

export const api = {
  epochen: () => anfrage<EpocheKurz[]>("/api/projects/epochen"),

  epocheLoeschen: (ordner: string) =>
    anfrage<void>(`/api/epochen/${encodeURIComponent(ordner)}`, { method: "DELETE" }),

  epocheDateienAuflisten: (ordner: string) =>
    anfrage<string[]>(`/api/epochen/${encodeURIComponent(ordner)}/dateien`),

  epocheDateiLesen: (ordner: string, name: string) =>
    anfrage<string>(`/api/epochen/${encodeURIComponent(ordner)}/dateien/${name}`),

  epocheDateiSchreiben: (ordner: string, name: string, inhalt: string) =>
    anfrage<{ gespeichert: boolean }>(
      `/api/epochen/${encodeURIComponent(ordner)}/dateien/${name}`,
      { method: "PUT", body: JSON.stringify({ inhalt }) },
    ),

  epocheGenreSchreiben: (ordner: string, genre: string) =>
    anfrage<{ genre: string | null }>(
      `/api/epochen/${encodeURIComponent(ordner)}/genre`,
      { method: "PUT", body: JSON.stringify({ genre }) },
    ),

  epocheFarbeSchreiben: (ordner: string, farbe: string) =>
    anfrage<{ farbe: string | null }>(
      `/api/epochen/${encodeURIComponent(ordner)}/farbe`,
      { method: "PUT", body: JSON.stringify({ farbe }) },
    ),

  projekte: () => anfrage<ProjektKurz[]>("/api/projects"),

  projektAnlegen: (titel: string, epoche: string, zweiteEpoche?: string | null) =>
    anfrage<ProjektKurz>("/api/projects", {
      method: "POST",
      // Leerer Titel ist erlaubt - das Backend legt dann einen Platzhalter-
      // Ordner "neu" an, der benannt wird, sobald das Architekten-Interview
      // einen Titel liefert. zweite_epoche ist optional (Zeitsprung-Projekt,
      // siehe app/core/epoche.py:zeitsprung_dateien_zusammenfuehren).
      body: JSON.stringify({ titel, epoche, zweite_epoche: zweiteEpoche || null }),
    }),

  projekt: (ordner: string) => anfrage<ProjektDetail>(`/api/projects/${ordner}`),

  analysatorStarten: (
    titel: string, epoche: string, text: string, zweiteEpoche?: string | null, sshZielId?: string | null,
    quelldatei?: string | null,
  ) =>
    anfrage<{ ordner: string }>(`/api/analysator/starten${sshQuery(sshZielId)}`, {
      method: "POST",
      body: JSON.stringify({
        titel, epoche, zweite_epoche: zweiteEpoche || null, text, quelldatei: quelldatei || null,
      }),
    }),

  fuelltextVorschau: (text: string) =>
    anfrage<FuelltextVorschau>("/api/analysator/fuelltext-vorschau", {
      method: "POST",
      body: JSON.stringify({ text }),
    }),

  uebersetzenStarten: (
    text: string, dateiname: string, fuelltextEntfernen: boolean, sshZielId?: string | null, fortsetzen = false,
  ) =>
    anfrage<{ dateiname: string }>(`/api/analysator/uebersetzen${sshQuery(sshZielId)}`, {
      method: "POST",
      body: JSON.stringify({ text, dateiname, fuelltext_entfernen: fuelltextEntfernen, fortsetzen }),
    }),

  /** Gibt es eine unterbrochene Übersetzung GENAU dieses Textes (Zuordnung über den Inhalt)? */
  uebersetzenFortsetzbar: (text: string) =>
    anfrage<UebersetzenFortsetzbar>("/api/analysator/uebersetzen/fortsetzbar", {
      method: "POST",
      body: JSON.stringify({ text }),
    }),

  uebersetzenStatus: () => anfrage<UebersetzenStatus>("/api/analysator/uebersetzen/status"),

  uebersetzenStoppen: () =>
    anfrage<{ stop_angefordert: boolean }>("/api/analysator/uebersetzen/stop", { method: "POST" }),

  /** zwischenstand: nur die vollständig übersetzten Kapitel (auch während des Laufs). */
  uebersetzenErgebnis: (zwischenstand = false) =>
    anfrage<string>(`/api/analysator/uebersetzen/ergebnis${zwischenstand ? "?zwischenstand=true" : ""}`),

  /** PDF der Übersetzung als Blob (kein JSON, deshalb ohne anfrage()). */
  uebersetzenPdf: async (zwischenstand = false): Promise<Blob> => {
    const antwort = await fetch(`/api/analysator/uebersetzen/pdf${zwischenstand ? "?zwischenstand=true" : ""}`, {
      credentials: "same-origin",
    });
    if (!antwort.ok) {
      let meldung = antwort.statusText;
      try {
        meldung = (await antwort.json()).detail ?? meldung;
      } catch {
        // Statustext reicht
      }
      throw new ApiError(String(meldung), antwort.status, meldung);
    }
    return antwort.blob();
  },

  /** Liest den Text einer PDF-Datei serverseitig (kein Speichern), siehe
   * backend/app/core/pdf_text.py. Kein JSON-Content-Type: der Browser setzt
   * bei FormData den multipart-Header selbst. */
  analysatorPdfText: (datei: File) => {
    const formular = new FormData();
    formular.append("datei", datei);
    return anfrage<{ text: string; seiten: number; woerter: number }>(
      "/api/analysator/pdf-text",
      { method: "POST", headers: {}, body: formular },
    );
  },

  analysatorStatus: (ordner: string) =>
    anfrage<AnalysatorStatus>(`/api/projects/${ordner}/analysator-status`),

  analysenAuflisten: () => anfrage<AnalyseEintrag[]>("/api/analysator/analysen"),

  analyseLesen: (dateiname: string) =>
    anfrage<string>(`/api/analysator/analysen/${encodeURIComponent(dateiname)}`),

  analyseLoeschen: (dateiname: string) =>
    anfrage<void>(`/api/analysator/analysen/${encodeURIComponent(dateiname)}`, { method: "DELETE" }),

  analysatorEpocheVorschlagen: (text: string, sshZielId?: string | null) =>
    anfrage<EpocheVorschlagAntwort>(`/api/analysator/epoche-vorschlagen${sshQuery(sshZielId)}`, {
      method: "POST",
      body: JSON.stringify({ text }),
    }),

  // EpocheErstellenPage.tsx legt Epochen bisher per Roh-fetch an (siehe
  // dortiger anlegen()) - dieser Wrapper ist NUR fuer AnalysatorPage.tsx
  // (Epoche-Ableiten-Weg), der denselben Endpunkt braucht, aber ueber das
  // einheitliche anfrage<T>()-Fehlerhandling laufen soll.
  epocheErstellen: (werte: EpocheVorschlagAntwort) =>
    anfrage<EpocheErstellenAntwort>("/api/epochen", {
      method: "POST",
      body: JSON.stringify(werte),
    }),

  projektLoeschen: (ordner: string) =>
    anfrage<void>(`/api/projects/${ordner}`, { method: "DELETE" }),

  projektEpocheAendern: (ordner: string, epoche: string) =>
    anfrage<ProjektKurz>(`/api/projects/${ordner}/epoche`, {
      method: "PUT",
      body: JSON.stringify({ epoche }),
    }),

  epocheUmbenennen: (ordner: string, name: string) =>
    anfrage<EpocheUmbenennenAntwort>(`/api/epochen/${encodeURIComponent(ordner)}/name`, {
      method: "PUT",
      body: JSON.stringify({ name }),
    }),

  projektNeuSchreiben: (ordner: string) =>
    anfrage<ProjektKurz>(`/api/projects/${ordner}/neu-schreiben`, { method: "POST" }),

  projektBereinigen: (ordner: string) =>
    anfrage<ProjektBereinigenAntwort>(`/api/projects/${ordner}/bereinigen`, { method: "POST" }),

  projektZuruecksetzen: (ordner: string) =>
    anfrage<ProjektZuruecksetzenAntwort>(`/api/projects/${ordner}/zuruecksetzen`, { method: "POST" }),

  projektOrdnerUmbenennen: (ordner: string, name: string) =>
    anfrage<{ neuer_ordner: string }>(`/api/projects/${ordner}/ordnername`, {
      method: "PUT",
      body: JSON.stringify({ name }),
    }),

  // KI entwirft das Gerüst aus Randbedingungen (siehe
  // backend/app/api/geruest_ki.py, KiGeruestOverlay.tsx) - Hintergrund-Task
  // wie der Analysator, das Frontend pollt danach kiGeruestStatus.
  kiGeruestStarten: (
    ordner: string, randbedingungen: KiGeruestRandbedingungen, sshZielId?: string | null,
  ) =>
    anfrage<{ gestartet: boolean }>(
      `/api/projects/${ordner}/geruest-ki/starten${sshQuery(sshZielId)}`,
      { method: "POST", body: JSON.stringify(randbedingungen) },
    ),

  kiGeruestStatus: (ordner: string) =>
    anfrage<KiGeruestStatus>(`/api/projects/${ordner}/geruest-ki/status`),

  /** Einmal aufgerufen, sobald GeruestPage "abgeschlossen" erkennt - benennt
   * den Ordner nach dem von der KI gewählten Titel um (server-seitig
   * synchron, siehe backend/app/api/geruest_ki.py:geruest_ki_ordner_anpassen).
   * Ohne diesen Aufruf bliebe der Ordner (und damit der PDF-Dateiname) bis
   * zum nächsten manuellen "Speichern" beim Platzhalternamen. */
  kiGeruestOrdnerAnpassen: (ordner: string) =>
    anfrage<{ neuer_ordner: string | null }>(`/api/projects/${ordner}/geruest-ki/ordner-anpassen`, {
      method: "POST",
    }),

  /** Die zuletzt für dieses Projekt abgeschickten Randbedingungen (oder null) -
   * das Overlay bietet sie beim Öffnen zum Übernehmen an, damit man nach einem
   * fehlgeschlagenen/abgebrochenen Lauf nicht alles neu tippen muss. */
  kiGeruestEingabe: (ordner: string) =>
    anfrage<KiGeruestRandbedingungen | null>(`/api/projects/${ordner}/geruest-ki/eingabe`),

  geruestSchreiben: (ordner: string, inhalt: string) =>
    anfrage<{
      gespeichert: string;
      gesichert_als: string | null;
      neuer_ordner: string | null;
      stand_00_aktualisiert: boolean;
    }>(`/api/projects/${ordner}/geruest`, { method: "PUT", body: JSON.stringify({ inhalt }) }),

  kapitel: (ordner: string, n: number) =>
    anfrage<string>(`/api/projects/${ordner}/kapitel/${n}`),

  kapitelSchreiben: (ordner: string, n: number, inhalt: string) =>
    anfrage<{ gesichert_als: string | null }>(
      `/api/projects/${ordner}/kapitel/${n}`,
      { method: "PUT", body: JSON.stringify({ inhalt }) },
    ),

  stand: (ordner: string, n: number) =>
    anfrage<string>(`/api/projects/${ordner}/stand/${n}`),

  befunde: (ordner: string, n: number) =>
    anfrage<BefundeAntwort>(`/api/projects/${ordner}/befunde/${n}`),

  befundAblehnen: (ordner: string, n: number, befundId: string) =>
    anfrage<{ abgelehnt: boolean }>(
      `/api/projects/${ordner}/befunde/${n}/ablehnen`,
      { method: "POST", body: JSON.stringify({ befund_id: befundId }) },
    ),

  /** Serverseitiges "Übernehmen" OHNE Monaco-Editor (Mobil-Ansicht,
   * MobilPage.tsx) - spleist den Vorschlag (oder `vorschlagOverride`, falls
   * vor dem Übernehmen leicht abgeändert) direkt in kapitel_NN.md und liefert
   * die aktualisierte, neu verankerte Funde-Liste zurück. */
  befundUebernehmen: (ordner: string, n: number, befundId: string, vorschlagOverride?: string) =>
    anfrage<BefundeAntwort>(
      `/api/projects/${ordner}/befunde/${n}/uebernehmen`,
      { method: "POST", body: JSON.stringify({ befund_id: befundId, vorschlag_override: vorschlagOverride ?? null }) },
    ),

  /** Konflikt-Fund (mehrere Prüfer mit sich widersprechenden Vorschlägen für
   * dieselbe Stelle, siehe BefundListe.tsx) per gezieltem LLM-Aufruf zu einem
   * gemeinsamen, übernehmbaren Vorschlag zusammenführen. */
  befundSynthese: (ordner: string, n: number, befundId: string, sshZielId?: string | null) =>
    anfrage<Befund>(
      `/api/projects/${ordner}/befunde/${n}/${befundId}/synthese${sshQuery(sshZielId)}`,
      { method: "POST" },
    ),

  gesamt: (ordner: string) => anfrage<string>(`/api/projects/${ordner}/gesamt`),

  architektenGespraech: (ordner: string) =>
    anfrage<string>(`/api/projects/${ordner}/architekten-gespraech`),

  architektFortsetzbar: (ordner: string) =>
    anfrage<{ fortsetzbar: boolean }>(`/api/projects/${ordner}/architekt-fortsetzbar`),

  architektVorlage: (ordner: string) =>
    anfrage<{ vorlage: string }>(`/api/projects/${ordner}/architekt-vorlage`),

  architektExtraktion: (ordner: string, handlungstext: string, sshZielId?: string | null) =>
    anfrage<{ vorlage: string }>(
      `/api/projects/${ordner}/architekt-extraktion${sshQuery(sshZielId)}`,
      { method: "POST", body: JSON.stringify({ handlungstext }) },
    ),

  verbotslisteSchreiben: (ordner: string, inhalt: string) =>
    anfrage<{ gesichert_als: string | null }>(
      `/api/projects/${ordner}/verbotsliste`,
      { method: "PUT", body: JSON.stringify({ inhalt }) },
    ),

  stilprobenSchreiben: (ordner: string, inhalt: string) =>
    anfrage<{ gesichert_als: string | null }>(
      `/api/projects/${ordner}/stilproben`,
      { method: "PUT", body: JSON.stringify({ inhalt }) },
    ),

  personasAuflisten: (ordner: string) => anfrage<string[]>(`/api/projects/${ordner}/personas`),

  personaLesen: (ordner: string, name: string) =>
    anfrage<string>(`/api/projects/${ordner}/personas/${name}`),

  personaSchreiben: (ordner: string, name: string, inhalt: string) =>
    anfrage<{ gesichert_als: string | null }>(
      `/api/projects/${ordner}/personas/${name}`,
      { method: "PUT", body: JSON.stringify({ inhalt }) },
    ),

  pruefen: (ordner: string, n: number, sshZielId?: string | null) =>
    anfrage<BefundeAntwort>(
      `/api/projects/${ordner}/pruefen/${n}${sshQuery(sshZielId)}`,
      { method: "POST" },
    ),

  standErzeugen: (ordner: string, n: number, sshZielId?: string | null) =>
    anfrage<{ stand: string; auto_export: boolean }>(
      `/api/projects/${ordner}/stand/${n}${sshQuery(sshZielId)}`,
      { method: "POST" },
    ),

  exportieren: (ordner: string) =>
    anfrage<{ gesamt: string; dateiname: string }>(`/api/projects/${ordner}/export`, { method: "POST" }),

  exportPdfUrl: (ordner: string) => `/api/projects/${ordner}/export/pdf`,

  coverPromptVorschlagen: (ordner: string, sshZielId?: string | null) =>
    anfrage<{ prompt: string }>(
      `/api/projects/${ordner}/cover/prompt-vorschlagen${sshQuery(sshZielId)}`,
      { method: "POST" },
    ),

  coverGenerieren: (
    ordner: string,
    prompt: string,
    bildZielId: string,
    bildModell: BildModell,
    sshZielId?: string | null,
    /** true = Performance-Warnung bereits bestätigt (Feature "KI- und
     * Speicherkontrolle"): den ggf. heruntergefahrenen Bild-Container jetzt
     * hochfahren, auch wenn gerade ein Automatik-Lauf läuft. */
    trotzSchreibens = false,
  ) => {
    const params = new URLSearchParams({ bild_ziel_id: bildZielId });
    if (sshZielId) params.set("ssh_ziel_id", sshZielId);
    if (trotzSchreibens) params.set("trotz_schreibens", "true");
    return anfrage<{ gespeichert: boolean }>(
      `/api/projects/${ordner}/cover/generieren?${params.toString()}`,
      { method: "POST", body: JSON.stringify({ prompt, bild_modell: bildModell }) },
    );
  },

  coverHochladen: (ordner: string, datei: File, kommentar?: string) => {
    const formular = new FormData();
    formular.append("datei", datei);
    if (kommentar) formular.append("kommentar", kommentar);
    // Kein "Content-Type": application/json wie im Default von anfrage() -
    // der Browser setzt bei FormData selbst den korrekten
    // multipart/form-data-Header inkl. Boundary, ein erzwungener JSON-Header
    // wuerde die Anfrage serverseitig unlesbar machen.
    return anfrage<{ gespeichert: boolean }>(
      `/api/projects/${ordner}/cover/hochladen`,
      { method: "POST", headers: {}, body: formular },
    );
  },

  coverUrl: (ordner: string) => `/api/projects/${ordner}/cover`,

  // Titelbild-Verlauf (siehe backend/app/core/cover_log.py) - jeder Aufruf
  // von coverGenerieren/coverHochladen legt serverseitig automatisch einen
  // Eintrag an, hier nur Lesen/Bearbeiten/Aktivieren/Löschen.
  coverLog: (ordner: string) => anfrage<CoverLogAntwort>(`/api/projects/${ordner}/cover/log`),

  coverLogBildUrl: (ordner: string, eintragId: string) =>
    `/api/projects/${ordner}/cover/log/${eintragId}/bild`,

  coverLogKommentarSetzen: (ordner: string, eintragId: string, kommentar: string) =>
    anfrage<{ gespeichert: boolean }>(
      `/api/projects/${ordner}/cover/log/${eintragId}/kommentar`,
      { method: "PUT", body: JSON.stringify({ kommentar }) },
    ),

  coverLogAktivieren: (ordner: string, eintragId: string) =>
    anfrage<{ gespeichert: boolean }>(
      `/api/projects/${ordner}/cover/log/${eintragId}/aktivieren`,
      { method: "POST" },
    ),

  coverLogLoeschen: (ordner: string, eintragId: string) =>
    anfrage<{ gelöscht: boolean }>(
      `/api/projects/${ordner}/cover/log/${eintragId}/loeschen`,
      { method: "POST" },
    ),

  anleitungUrl: () => "/api/docs/anleitung",

  hilfeUrl: () => "/api/docs/hilfe",

  zusammenfassen: (ordner: string, von?: number, bis?: number) => {
    const params = new URLSearchParams();
    if (von !== undefined) params.set("von", String(von));
    if (bis !== undefined) params.set("bis", String(bis));
    const query = params.toString() ? `?${params.toString()}` : "";
    return anfrage<{ datei?: string; gesamt?: string; dateiname?: string; inhalt?: string }>(
      `/api/projects/${ordner}/zusammenfassen${query}`,
      { method: "POST" },
    );
  },

  rechtschreibung: (ordner: string, n: number, sshZielId?: string | null) =>
    anfrage<RechtschreibAntwort>(
      `/api/projects/${ordner}/rechtschreibung/${n}${sshQuery(sshZielId)}`,
    ),

  automatikStarten: (
    ordner: string,
    maxDurchlaeufe: number,
    sshZielId?: string | null,
    fortsetzen = false,
    automatischBestaetigen = false,
    nurNeueKapitel = false,
    speicherkontrolleGestoppt: string[] = [],
    nachFertigSound = false,
    nachFertigHerunterfahren = false,
  ) =>
    anfrage<{ gestartet: boolean }>(
      `/api/projects/${ordner}/automatik/start${sshQuery(sshZielId)}`,
      {
        method: "POST",
        body: JSON.stringify({
          max_durchlaeufe: maxDurchlaeufe,
          fortsetzen,
          automatisch_bestaetigen: automatischBestaetigen,
          nur_neue_kapitel: nurNeueKapitel,
          speicherkontrolle_gestoppt: speicherkontrolleGestoppt,
          nach_fertig_sound: nachFertigSound,
          nach_fertig_herunterfahren: nachFertigHerunterfahren,
        }),
      },
    ),

  automatikHerunterfahrenAbbrechen: (ordner: string) =>
    anfrage<{ abgebrochen: boolean }>(
      `/api/projects/${ordner}/automatik/herunterfahren-abbrechen`,
      { method: "POST" },
    ),

  automatikFortsetzenVorschau: (ordner: string) =>
    anfrage<AutomatikFortsetzenVorschau>(
      `/api/projects/${ordner}/automatik/fortsetzen-vorschau`,
    ),

  automatikStatus: (ordner: string) =>
    anfrage<AutomatikStatus>(`/api/projects/${ordner}/automatik/status`),

  automatikStoppen: (ordner: string) =>
    anfrage<{ stop_angefordert: boolean }>(`/api/projects/${ordner}/automatik/stop`, { method: "POST" }),

  automatikVerlauf: (ordner: string) =>
    anfrage<AutomatikVerlaufEintrag[]>(`/api/projects/${ordner}/automatik/verlauf`),

  automatikResteBestaetigen: (ordner: string) =>
    anfrage<{ resten_bestaetigt: boolean }>(`/api/projects/${ordner}/automatik/resten-bestaetigen`, { method: "POST" }),

  sshZiele: () => anfrage<SSHZiel[]>("/api/ssh-targets"),

  sshZielAnlegen: (daten: SSHZielEingabe) =>
    anfrage<SSHZiel>("/api/ssh-targets", {
      method: "POST",
      body: JSON.stringify(daten),
    }),

  sshZielAktualisieren: (id: string, daten: SSHZielEingabe) =>
    anfrage<SSHZiel>(`/api/ssh-targets/${id}`, {
      method: "PUT",
      body: JSON.stringify(daten),
    }),

  sshZielLoeschen: (id: string) =>
    anfrage<void>(`/api/ssh-targets/${id}`, { method: "DELETE" }),

  sshZielFavoritSetzen: (id: string, favorit: boolean) =>
    anfrage<SSHZiel>(`/api/ssh-targets/${id}/favorit`, {
      method: "PUT",
      body: JSON.stringify({ favorit }),
    }),

  sshZielTesten: (id: string) =>
    anfrage<SSHTestErgebnis>(`/api/ssh-targets/${id}/test`, { method: "POST" }),

  sshZielErreichbar: (id: string) =>
    anfrage<SSHTestErgebnis>(`/api/ssh-targets/${id}/erreichbar`),

  sshVerbindungTestenUngespeichert: (daten: SSHZielEingabe) =>
    anfrage<SSHTestErgebnis>("/api/ssh-targets/test", {
      method: "POST",
      body: JSON.stringify(daten),
    }),

  kiStarten: (zielId: string) =>
    anfrage<KiStartStatus>(`/api/ssh-targets/${zielId}/ki-starten`, { method: "POST" }),

  kiStartenStatus: (zielId: string) => anfrage<KiStartStatus>(`/api/ssh-targets/${zielId}/ki-starten`),

  sshZielModelle: (id: string) => anfrage<OllamaModellInfo[]>(`/api/ssh-targets/${id}/modelle`),

  personaModelle: (zielId: string) =>
    anfrage<PersonaModell[]>(`/api/persona-modelle?ziel_id=${encodeURIComponent(zielId)}`),

  personaModellSetzen: (zielId: string, persona: string, modell: string | null) =>
    anfrage<PersonaModell>(`/api/persona-modelle/${encodeURIComponent(persona)}?ziel_id=${encodeURIComponent(zielId)}`, {
      method: "PUT",
      body: JSON.stringify({ modell }),
    }),

  // --- Projekt-Abgleich (siehe backend/app/api/sync.py) ---
  syncPartner: () => anfrage<SyncPartner>("/api/sync/partner"),
  syncPartnerSchreiben: (url: string, username: string, password: string | null) =>
    anfrage<SyncPartner>("/api/sync/partner", { method: "PUT", body: JSON.stringify({ url, username, password }) }),
  syncPartnerLoeschen: () => anfrage<void>("/api/sync/partner", { method: "DELETE" }),
  syncPartnerTesten: () => anfrage<{ ok: boolean; projekte: number }>("/api/sync/partner/test", { method: "POST" }),
  syncVergleich: () => anfrage<{ zeilen: SyncZeile[] }>("/api/sync/vergleich"),
  syncHochladen: (ordner: string, force: boolean) =>
    anfrage<{ uebertragen: boolean; nachricht: string }>("/api/sync/hochladen", {
      method: "POST",
      body: JSON.stringify({ ordner, force }),
    }),
  syncHerunterladen: (ordner: string, force: boolean) =>
    anfrage<{ uebertragen: boolean; nachricht: string }>("/api/sync/herunterladen", {
      method: "POST",
      body: JSON.stringify({ ordner, force }),
    }),
  syncLokalAufraeumen: (ordner: string, vorherHochladen: boolean) =>
    anfrage<{ entfernt: boolean; nachricht: string }>("/api/sync/lokal-aufraeumen", {
      method: "POST",
      body: JSON.stringify({ ordner, vorher_hochladen: vorherHochladen }),
    }),
  syncAufraeumenVormerken: (ordner: string) =>
    anfrage<{ vorgemerkt: boolean }>("/api/sync/aufraeumen-vormerken", {
      method: "POST",
      body: JSON.stringify({ ordner, vormerken: true }),
    }),
  syncProjektStatus: (ordner: string) =>
    anfrage<SyncProjektStatus>(`/api/sync/projekt-status?ordner=${encodeURIComponent(ordner)}`),

  einstellungen: () => anfrage<Einstellungen>("/api/einstellungen"),

  // PUT /api/einstellungen ist ein vollstaendiger Ersatz, kein Teilupdate -
  // deshalb erwartet diese Funktion IMMER alle Felder (siehe
  // EinstellungenPage.tsx:speichern, das sie aus dem State zusammenbaut).
  einstellungenSchreiben: (werte: {
    projectsDir: string;
    unterordnerJeEpoche: boolean;
    bildgeneratorUrl?: string;
    unnuetzesWissenAktiv: boolean;
    unnuetzesWissenStartSekunden: number;
    unnuetzesWissenWechselSekunden: number;
    speicherkontrolleAktiv: boolean;
    speicherkontrolleContainer: string[];
  }) =>
    anfrage<Einstellungen>("/api/einstellungen", {
      method: "PUT",
      body: JSON.stringify({
        projects_dir: werte.projectsDir,
        unterordner_je_epoche: werte.unterordnerJeEpoche,
        bildgenerator_url: werte.bildgeneratorUrl,
        unnuetzes_wissen_aktiv: werte.unnuetzesWissenAktiv,
        unnuetzes_wissen_start_sekunden: werte.unnuetzesWissenStartSekunden,
        unnuetzes_wissen_wechsel_sekunden: werte.unnuetzesWissenWechselSekunden,
        speicherkontrolle_aktiv: werte.speicherkontrolleAktiv,
        speicherkontrolle_container: werte.speicherkontrolleContainer,
      }),
    }),

  hostStatus: (zielId: string) => anfrage<HostStatus>(`/api/ssh-targets/${zielId}/host-status`),

  hostContainer: (zielId: string, name: string, aktion: "start" | "stop") =>
    anfrage<HostContainerInfo>(
      `/api/ssh-targets/${zielId}/container/${encodeURIComponent(name)}/${aktion}`,
      { method: "POST" },
    ),

  unnuetzesWissen: () => anfrage<WissenEintrag[]>("/api/unnuetzeswissen"),

  unnuetzesWissenNaechstes: () => anfrage<WissenNaechstesAntwort>("/api/unnuetzeswissen/naechstes"),

  login: (eingabe: LoginEingabe) =>
    anfrage<Benutzer>("/api/auth/login", { method: "POST", body: JSON.stringify(eingabe) }),

  logout: () => anfrage<void>("/api/auth/logout", { method: "POST" }),

  me: () => anfrage<Benutzer>("/api/auth/me"),

  benutzerListe: () => anfrage<BenutzerEintrag[]>("/api/benutzer"),

  benutzerAnlegen: (daten: BenutzerAnlegenEingabe) =>
    anfrage<BenutzerEintrag>("/api/benutzer", { method: "POST", body: JSON.stringify(daten) }),

  benutzerLoeschen: (id: number) =>
    anfrage<void>(`/api/benutzer/${id}`, { method: "DELETE" }),

  fundusLesen: () => anfrage<string>("/api/fundus"),

  fundusSchreiben: (inhalt: string) =>
    anfrage<{ gesichert_als: string | null }>("/api/fundus", {
      method: "PUT",
      body: JSON.stringify({ inhalt }),
    }),

  fundusImportieren: (sshZielId?: string | null) =>
    anfrage<FundusImportAntwort>(`/api/fundus/import${sshQuery(sshZielId)}`, { method: "POST" }),

  fundusProjektAktualisieren: (ordner: string, sshZielId?: string | null) =>
    anfrage<FundusProjektAntwort>(`/api/fundus/projekt/${ordner}${sshQuery(sshZielId)}`, { method: "POST" }),

  fundusFigurenLesen: () => anfrage<FundusFigurenAntwort>("/api/fundus/figuren"),

  fundusFigurAnlegen: (epoche: string, name: string, felder: Record<string, string>) =>
    anfrage<FundusFigur>("/api/fundus/figuren", {
      method: "POST",
      body: JSON.stringify({ epoche, name, felder }),
    }),

  fundusFigurAktualisieren: (
    epoche: string,
    name: string,
    felder: Record<string, string>,
    neuerName?: string,
    neueEpoche?: string,
  ) =>
    anfrage<FundusFigur>("/api/fundus/figuren", {
      method: "PUT",
      body: JSON.stringify({ epoche, name, neuer_name: neuerName ?? null, neue_epoche: neueEpoche ?? null, felder }),
    }),

  fundusFigurLoeschen: (epoche: string, name: string) =>
    anfrage<{ gelöscht: boolean }>(
      `/api/fundus/figuren?${new URLSearchParams({ epoche, name })}`,
      { method: "DELETE" },
    ),

  fundusFigurKopieren: (epoche: string, name: string, zielEpoche: string, neuerName?: string) =>
    anfrage<FundusFigur>("/api/fundus/figuren/kopieren", {
      method: "POST",
      body: JSON.stringify({ epoche, name, ziel_epoche: zielEpoche, neuer_name: neuerName ?? null }),
    }),

  fundusFeldHinzufuegen: (epoche: string, name: string, feldName: string, wert: string, fuerAlle: boolean) =>
    anfrage<FundusFigur>("/api/fundus/felder", {
      method: "POST",
      body: JSON.stringify({ epoche, name, feld_name: feldName, wert, fuer_alle: fuerAlle }),
    }),

  // Orte-Fundus (siehe backend/app/api/orte.py) - gleiches Muster wie der
  // Personen-Fundus oben, aber ohne Import/Custom-Felder.
  orteLesen: () => anfrage<string>("/api/orte"),

  orteSchreiben: (inhalt: string) =>
    anfrage<{ gesichert_als: string | null }>("/api/orte", {
      method: "PUT",
      body: JSON.stringify({ inhalt }),
    }),

  orteListeLesen: () => anfrage<OrteAntwort>("/api/orte/orte"),

  ortAnlegen: (epoche: string, name: string, beschreibung: string) =>
    anfrage<Ort>("/api/orte/orte", {
      method: "POST",
      body: JSON.stringify({ epoche, name, beschreibung }),
    }),

  ortAktualisieren: (
    epoche: string, name: string, beschreibung: string, neuerName?: string, neueEpoche?: string,
  ) =>
    anfrage<Ort>("/api/orte/orte", {
      method: "PUT",
      body: JSON.stringify({
        epoche, name, neuer_name: neuerName ?? null, neue_epoche: neueEpoche ?? null, beschreibung,
      }),
    }),

  ortLoeschen: (epoche: string, name: string) =>
    anfrage<{ gelöscht: boolean }>(
      `/api/orte/orte?${new URLSearchParams({ epoche, name })}`,
      { method: "DELETE" },
    ),
};

export function schreibenWebSocketUrl(
  ordner: string,
  n: number,
  zusatzhinweis: string,
  sshZielId?: string | null,
): string {
  const protokoll = window.location.protocol === "https:" ? "wss" : "ws";
  const params = new URLSearchParams();
  if (zusatzhinweis) params.set("zusatzhinweis", zusatzhinweis);
  if (sshZielId) params.set("ssh_ziel_id", sshZielId);
  const query = params.toString() ? `?${params.toString()}` : "";
  return `${protokoll}://${window.location.host}/api/projects/${ordner}/ws/schreiben/${n}${query}`;
}

export function architektWebSocketUrl(ordner: string, sshZielId?: string | null): string {
  const protokoll = window.location.protocol === "https:" ? "wss" : "ws";
  const params = new URLSearchParams();
  if (sshZielId) params.set("ssh_ziel_id", sshZielId);
  const query = params.toString() ? `?${params.toString()}` : "";
  return `${protokoll}://${window.location.host}/api/projects/${ordner}/ws/architekt${query}`;
}
