// Spiegelt backend/app/schemas.py - bei Aenderungen dort bitte hier nachziehen.

export interface EpocheKurz {
  // Ordner-/Identifier-Name - stabil, siehe backend/app/schemas.py:
  // EpocheKurz. Fuer Anzeigezwecke immer `anzeigename` verwenden.
  name: string;
  anzeigename: string;
  genre?: string | null;
  farbe?: string | null;
}

// PUT /api/epochen/{ordner}/name
export interface EpocheUmbenennenAntwort {
  ordner: string;
  anzeigename: string;
  aktualisierte_projekte: number;
}

// Siehe app/core/automatik.py:zustand_zusammenfassen() für die Bedeutung
// der einzelnen Werte - null heißt: Automatikmodus wurde für dieses
// Projekt noch nie gestartet.
export type AutomatikZustand = "laeuft" | "fehler" | "gestoppt" | "abgeschlossen_mit_resten" | "abgeschlossen_sauber" | null;

export interface ProjektKurz {
  ordner: string;
  titel: string | null;
  epoche: string | null;
  // Nur gesetzt bei einem Zeitsprung-Projekt (zweite, per Zeitsprung
  // erreichte Epoche) - siehe ProjektAnlegenAnfrage.zweite_epoche.
  zweite_epoche?: string | null;
  anzahl_kapitel: number;
  letztes_geplantes_kapitel: number | null;
  automatik_zustand: AutomatikZustand;
  // Nur gesetzt, wenn dieses Projekt per "Neu schreiben" aus einem anderen
  // dupliziert wurde - Ordnerpfad des Quellprojekts (Titel/Gerüst werden
  // 1:1 mitkopiert, ohne dieses Feld waeren beide Projekte in der Liste
  // nicht unterscheidbar).
  neu_geschrieben_aus?: string | null;
  // "YYYY-MM-DD HH:MM", siehe backend/app/api/projects.py:_erstellt_am /
  // _zuletzt_bearbeitet_am.
  erstellt_am?: string | null;
  zuletzt_bearbeitet_am?: string | null;
}

export interface ProjektDetail {
  ordner: string;
  epoche: string | null;
  zweite_epoche?: string | null;
  geruest: string | null;
  verbotsliste: string | null;
  stilproben: string | null;
  kapitel: number[];
  jahr: string | null;
  jugendschutz_stufe: string | null;
  autor_modell: string | null;
  automatische_fortsetzung: boolean | null;
  letztes_geplantes_kapitel: number | null;
  kapitelplan: Record<number, number>;
}

export type AuthMethod = "password" | "private_key" | "agent" | "direct";

export interface SSHZiel {
  id: string;
  name: string;
  host: string;
  port: number;
  username: string;
  auth_method: AuthMethod;
  remote_ollama_port: number;
  // Port eines sd-server-Containers auf demselben Host (Bildgenerierung,
  // siehe api.coverPromptVorschlagen/coverGenerieren) - null = dieses
  // KI-Ziel bietet keine Bildgenerierung an.
  bildki_port: number | null;
  // Zweiter, unabhaengiger sd-server-Port fuer Pony Diffusion + Realism-LoRA
  // (siehe backend/app/core/bild_generierung.py) - null = kein Pony-Modell
  // auf diesem KI-Ziel verfuegbar. bildki_port bleibt FLUX.
  bildki_port_pony: number | null;
  // Port des athene-steuerung-Dienstes (Feature "KI- und Speicherkontrolle",
  // siehe athene/README.md) - null = dieses KI-Ziel kann Container/RAM nicht
  // fernsteuern. Nur fuer 'direct'-Ziele relevant.
  steuer_port: number | null;
  steuer_token_gesetzt: boolean;
  favorit: boolean;
  created_at: string;
  updated_at: string;
}

export interface SSHZielEingabe {
  name: string;
  host: string;
  port: number;
  username: string;
  auth_method: AuthMethod;
  password?: string;
  private_key_pem?: string;
  private_key_passphrase?: string;
  remote_ollama_port: number;
  bildki_port?: number | null;
  bildki_port_pony?: number | null;
  steuer_port?: number | null;
  // Leer = unveraendert lassen (analog zu Passwoertern); nur ein neu
  // eingegebener Token ueberschreibt.
  steuer_token?: string;
}

export interface HostSpeicherInfo {
  total_mb: number;
  available_mb: number;
  used_mb: number;
}

export interface HostContainerInfo {
  name: string;
  running: boolean;
}

export interface HostStatus {
  verfuegbar: boolean;
  ram: HostSpeicherInfo;
  swap: HostSpeicherInfo;
  containers: HostContainerInfo[];
  ollama: { name: string; processor: string }[];
  herunterfahren_empfohlen: boolean;
}

// Welches Bildmodell fuer die Cover-Generierung genutzt wird (siehe
// backend/app/core/bild_generierung.py) - "flux" (Standard) = FLUX.1-schnell,
// "pony" = Pony Diffusion V6 XL + Realism-LoRA (fotorealistisch, ohne die
// Content-Einschraenkung des automatischen Prompt-Vorschlags).
export type BildModell = "flux" | "pony";

export interface SSHTestErgebnis {
  erfolgreich: boolean;
  meldung: string;
}

export interface OllamaModellInfo {
  name: string;
  parameter_size: string | null;
  size_bytes: number | null;
}

// "KI starten & Modelle scannen" (backend/app/core/ki_start.py): laeuft im
// Hintergrund, das Frontend fragt den Fortschritt ab.
export interface KiStartStatus {
  laeuft: boolean;
  fertig: boolean;
  erfolgreich: boolean | null;
  schritte: string[];
  fehler: string | null;
  modelle: OllamaModellInfo[];
  fehlende_modelle: string[];
}

// /api/persona-modelle - Admin-Zuordnung Persona -> Ollama-Modell je KI-Ziel
// (Tab "KI-Ziele" -> Persona-Modell-Zuordnung).
export interface PersonaModell {
  persona: string;
  default_modell: string;
  override_modell: string | null;
  effektives_modell: string;
}

export interface Finding {
  code: string;
  meldung: string;
  schwere: "warnung" | "info";
}

export type BefundKategorie = "anachronismus" | "stimmigkeit" | "kontinuitaet" | "lektorat";

export interface BefundBeschreibung {
  quelle: string;
  text: string;
}

export interface Befund {
  id: string;
  kategorien: BefundKategorie[];
  fundstelle: string;
  beschreibungen: BefundBeschreibung[];
  sicherheit: "hoch" | "mittel" | "gering" | null;
  vorschlag: string | null;
  konflikt: boolean;
  konflikt_vorschlaege: BefundBeschreibung[] | null;
  gefunden: boolean;
  start: number | null;
  end: number | null;
}

export interface BefundeAntwort {
  kapitel: number;
  erzeugt_am: string;
  jahr: string | null;
  befunde: Befund[];
  quelltext_sha256: string | null;
  /** true, wenn der Kapiteltext seit dieser Pruefung ueberschrieben wurde -
   * die start/end-Offsets in `befunde` koennen dann auf falsche Stellen
   * zeigen (siehe befunde_lesen() im Backend). */
  veraltet: boolean;
}

export interface RechtschreibWort {
  wort: string;
  satz: string | null;
  // Zeichen-Offsets der ersten Fundstelle im vollen Kapiteltext, fuer den
  // Sprung-zur-Stelle-Klick - siehe app/core/heuristik.py:wort_position_finden.
  start: number | null;
  end: number | null;
}

export interface RechtschreibAntwort {
  unbekannte_woerter: RechtschreibWort[];
  hunspell_verfuegbar: boolean;
}

// /api/projects/{ordner}/automatik/* - schreibt alle fehlenden Kapitel am
// Stück und wendet danach automatisch alle eindeutigen Prüfer-Korrekturen
// an (siehe app/core/automatik.py). Läuft als Hintergrund-Job unabhängig
// von einer offenen Browser-Verbindung - dieser Status wird per Polling
// abgefragt, nicht per WebSocket.
export interface AutomatikProtokollEintrag {
  art: "angewendet" | "uebersprungen" | "rechtschreibung";
  grund?: string | null;
  fundstelle?: string | null;
  vorschlag?: string | null;
  kapitel?: number;
  durchlauf?: number;
  unbekannte_woerter?: string[];
}

// Deckungsgleich mit EpocheFormularWerte (components/EpocheFormular.tsx) -
// bewusst als eigener API-Antworttyp gefuehrt (kein Re-Export), damit
// api/types.ts nicht von components/ abhaengt; AnalysatorPage.tsx weist das
// Ergebnis direkt in ein EpocheFormularWerte-State, da beide Formen
// strukturell identisch sind.
export interface EpocheVorschlagAntwort {
  name: string;
  erfunden: boolean;
  beschreibung: string;
  zeitraum: string;
  orte: string;
  gesellschaft: string;
  statusregel: string;
  genre: string;
  rang_wort: string;
  anreden: string;
  nebenstrang_typen: string;
  vorbild_franchise: string;
  verbote_start: string;
}

export interface EpocheErstellenAntwort {
  name: string;
  ordner: string;
  dateien: Record<string, string>;
}

// Analysator "Ins Deutsche übersetzen" (backend/app/core/uebersetzer.py)
export interface FuelltextVorschau {
  sprache: "de" | "en" | "unbekannt";
  woerter: number;
  fuelltext_absaetze: number;
  beispiele: string[];
  abschnitte: number;
  geschaetzte_minuten: number;
}

export interface UebersetzenFortsetzbar {
  fortsetzbar: boolean;
  dateiname: string | null;
  kapitel_fertig: number;
  kapitel_gesamt: number;
  woerter_fertig: number;
  woerter_gesamt: number;
  ergebnis_woerter: number;
}

export interface UebersetzenStatus {
  laeuft: boolean;
  abgeschlossen: boolean;
  gestoppt: boolean;
  stop_angefordert: boolean;
  aktuell: number;
  gesamt: number;
  log: string[];
  fehler: string | null;
  dateiname: string | null;
  ergebnis_woerter: number;
  fuelltext_entfernt: number;
  kapitel_gesamt: number;
  kapitel_fertig: number;
  woerter_gesamt: number;
  woerter_fertig: number;
  fortgesetzt: boolean;
}

export interface AnalysatorStatus {
  laeuft: boolean;
  phase: string | null;
  aktuelles_kapitel: number | null;
  gesamt_kapitel: number | null;
  log: string[];
  abgeschlossen: boolean;
  fehler: string | null;
}

// POST /api/projects/{ordner}/geruest-ki/starten - Randbedingungen, aus denen
// die KI einen Kapitelplan-Erstentwurf baut (siehe
// backend/app/schemas.py:KiGeruestStartAnfrage und
// frontend/src/components/KiGeruestOverlay.tsx). Nur praemisse + kapitelanzahl
// sind Pflicht.
export interface KiGeruestFigurEingabe {
  name: string;
  alter: string;
  rolle: string;
  kurzbeschreibung: string;
}

export interface KiGeruestRandbedingungen {
  praemisse: string;
  kapitelanzahl: number;
  setting: string;
  zielwortzahl_pro_kapitel: number;
  figuren: KiGeruestFigurEingabe[];
  genre: string;
  verlauf: string;
  konflikt: string;
  dramatik: string;
  zeitraum: string;
  schluss: string;
  tabus: string;
  sprache: string;
  jahr: string;
  jugendschutz_stufe: string;
}

// GET /api/projects/{ordner}/geruest-ki/status
export interface KiGeruestStatus {
  laeuft: boolean;
  phase: string | null;
  log: string[];
  abgeschlossen: boolean;
  fehler: string | null;
}

// /api/analysator/analysen - dauerhaft gespeicherte Rohtexte importierter
// Geschichten (siehe backend/app/core/analysator.py:analyse_speichern).
export interface AnalyseEintrag {
  /** Datei, aus der der Text stammt (z.B. "Buch.pdf") - null bei älteren Einträgen. */
  quelldatei?: string | null;
  dateiname: string;
  titel: string;
  erstellt_am: string;
  woerter: number;
}

export interface AutomatikStatus {
  laeuft: boolean;
  gestartet_am: string | null;
  phase: string | null;
  aktuelles_kapitel: number | null;
  gesamt_kapitel: number | null;
  aktueller_durchlauf: number | null;
  log: string[];
  protokoll: AutomatikProtokollEintrag[];
  stop_angefordert: boolean;
  abgeschlossen: boolean;
  fehler: string | null;
  fortsetzbar: boolean;
  resten_bestaetigt: boolean;
  // Nur gesetzt, wenn der letzte Lauf nach ausgeschoepften 502/503-Retries
  // pausiert wurde (siehe app/api/pipeline.py:_automatik_mit_retry) - fuer
  // die kompakte Fortsetzen-Zeile.
  /** Live-Text des Autors waehrend des Automatikmodus (siehe
   * app/api/pipeline.py:_automatik_on_event) - fuellt dasselbe "Autor"-
   * Fenster wie beim interaktiven Schreiben, nur ohne WebSocket. */
  aktueller_text: string | null;
  fehler_schritt: {
    kapitel: number;
    phase: string;
    durchlauf: number | null;
    fehler_nummer?: string;
  } | null;
  /** Feature "KI- und Speicherkontrolle": Container, die dieser Lauf am
   * Anfang heruntergefahren hat - nach Lauf-Ende bietet das Frontend das
   * Wiederhochfahren an. */
  speicherkontrolle_gestoppt: string[];
  /** Optionen des Laufs: Signalton bzw. PC herunterfahren nach sauberem Ende. */
  nach_fertig_sound: boolean;
  nach_fertig_herunterfahren: boolean;
  /** Unix-Zeit (Sekunden), zu der der PC herunterfaehrt - null = nichts geplant. */
  herunterfahren_geplant_bis: number | null;
  /** Backend laeuft unter Windows - nur dann ist "PC herunterfahren" waehlbar. */
  herunterfahren_moeglich: boolean;
}

// Ein Eintrag pro bisherigem Automatik-Lauf dieses Projekts (dauerhaftes
// Protokoll, unabhaengig vom aktuellen Status) - siehe
// app/core/automatik.py:verlauf_eintrag_anhaengen.
export interface AutomatikVerlaufEintrag {
  datum: string;
  von: string;
  bis: string;
  dauer_sekunden: number;
  status: "abgeschlossen" | "fehler" | "gestoppt";
  fehler: string | null;
  fortgesetzt: boolean;
}

// Vorschau vor dem inkrementellen Erweitern ("Weitere Kapitel schreiben") -
// siehe app/api/pipeline.py:automatik_fortsetzen_vorschau. Reine
// Datei-/Kapitelplan-Auswertung, kein KI-Aufruf.
export interface AutomatikAnknuepfpunkt {
  kapitel: number;
  stand_vorhanden: boolean;
  stand_text: string | null;
  stand_veraltet: boolean;
}

export interface AutomatikFortsetzenVorschau {
  geplant_bis: number | null;
  kapitelplan: Record<number, number>;
  geschrieben: number[];
  naechstes_kapitel: number | null;
  zu_schreiben: number[];
  anknuepfpunkt: AutomatikAnknuepfpunkt | null;
}

export interface FundusImportAntwort {
  importierte_projekte: number;
  gefundene_figuren: number;
  uebersprungen: string[];
}

export interface FundusProjektAntwort {
  gefundene_figuren: number;
  uebersprungen: boolean;
}

export interface FundusFigur {
  epoche: string;
  name: string;
  /** Insertion-geordnet: Standardfelder zuerst, dann eigene Zusatzfelder, "Geschichten" immer zuletzt. */
  felder: Record<string, string>;
}

export interface FundusFigurenAntwort {
  figuren: FundusFigur[];
  standard_felder: string[];
}

// Titelbild-Verlauf (siehe backend/app/core/cover_log.py) - ein Eintrag je
// Aufruf von cover/generieren oder cover/hochladen. Das Bild selbst wird
// separat ueber api.coverLogBildUrl() geladen, um diese Liste klein zu halten.
export interface CoverLogEintrag {
  id: string;
  zeitpunkt: string;
  herkunft: "generiert" | "hochgeladen";
  prompt_deutsch: string;
  prompt_englisch: string;
  kommentar: string;
  // "flux"/"pony" bei KI-generierten Eintraegen, leer bei hochgeladenen
  // Bildern oder Eintraegen aus der Zeit vor dieser Unterscheidung.
  modell: string;
}

export interface CoverLogAntwort {
  eintraege: CoverLogEintrag[];
  // Id des Eintrags, dessen Bild aktuell als Titelbild aktiv ist - null,
  // wenn kein Eintrag (mehr) dem aktuellen Titelbild entspricht.
  aktive_id: string | null;
}

// Orte-Fundus (siehe backend/app/core/orte.py) - Pendant zu FundusFigur,
// aber ohne dynamische Zusatzfelder: nur Name + Beschreibung je Epoche.
export interface Ort {
  epoche: string;
  name: string;
  beschreibung: string;
}

export interface OrteAntwort {
  orte: Ort[];
}

export interface ProjektBereinigenAntwort {
  geloeschte_bak: number;
  geloeschte_stand: number;
}

export interface ProjektZuruecksetzenAntwort {
  geloeschte_dateien: number;
  geloeschte_bak: number;
}

export interface Einstellungen {
  projects_dir: string;
  ist_standard: boolean;
  standard_projects_dir: string;
  unterordner_je_epoche: boolean;
  /** Link zu einer externen Bildgenerierungs-Weboberflaeche (z.B. Google
   * Gemini) - Schnellzugriff im Titelbild-Bereich (Stand & Export). */
  bildgenerator_url: string;
  bildgenerator_url_ist_standard: boolean;
  /** Zeit-Ueberbrueckungs-Overlay "Unnuetzes Wissen" (siehe
   * components/ZeitUeberbrueckungOverlay.tsx): komplett abschaltbar, sonst
   * konfigurierbar wann es waehrend einer KI-Wartezeit erscheint und wie
   * schnell es weiterblaettert. */
  unnuetzes_wissen_aktiv: boolean;
  unnuetzes_wissen_start_sekunden: number;
  unnuetzes_wissen_wechsel_sekunden: number;
  /** Feature "KI- und Speicherkontrolle": beim Schreibstart anbieten, nicht
   * benoetigte Container auf dem KI-Host herunterzufahren (mehr RAM fuer den
   * Autor). speicherkontrolle_container = Namen der abzuschaltenden Container. */
  speicherkontrolle_aktiv: boolean;
  speicherkontrolle_container: string[];
}

// /api/auth/*
export interface Benutzer {
  id: number;
  username: string;
  ist_admin: boolean;
}

export interface LoginEingabe {
  username: string;
  password: string;
}

// /api/benutzer/* - nur fuer Admin-Benutzer erreichbar (siehe Tab "Benutzer")
export interface BenutzerEintrag {
  id: number;
  username: string;
  ist_admin: boolean;
  created_at: string;
}

export interface BenutzerAnlegenEingabe {
  username: string;
  password: string;
  ist_admin: boolean;
}

export interface WissenEintrag {
  nummer: number;
  kategorie: string;
  thema: string;
  kuriositaet: string;
  hintergrund: string;
  quelle: string | null;
}

// /api/unnuetzeswissen/naechstes - liefert Eintraege in einer serverseitig
// gemerkten, einmal gemischten Reihenfolge statt rein zufaellig, damit
// jeder Eintrag garantiert einmal drankommt bevor sich etwas wiederholt.
export interface WissenNaechstesAntwort {
  eintrag: WissenEintrag;
  position: number;
  gesamt: number;
}

// WebSocket-Nachrichten von /api/projects/{ordner}/ws/schreiben/{n}
export type SchreibenNachricht =
  | { phase: "stand_nachholen"; typ: "start" | "done"; kapitel: number }
  | { phase: "autor"; typ: "start"; modell: string; ziel_woerter: number | null }
  | { phase: "autor"; typ: "thinking" | "content"; text: string }
  | { phase: "autor"; typ: "done"; meta: Record<string, unknown> }
  | { phase: "autor"; typ: "error"; text: string }
  | {
      phase: "nachbearbeitung";
      typ: "done";
      findings: Finding[];
      gesichert_als: string | null;
      titelseite_hinzugefuegt: boolean;
    }
  | { phase: "pruefen"; typ: "start" }
  | { phase: "pruefen"; typ: "done"; befunde: BefundeAntwort }
  | { phase: "abgeschlossen"; kapitel_text: string }
  | { phase: "fehler"; typ: "error"; text: string };

// WebSocket-Nachrichten von /api/projects/{ordner}/ws/architekt
export type ArchitektNachricht =
  | { phase: "fortgesetzt"; verlauf: string[] }
  | { phase: "zurueckgesetzt"; verlauf: string[] }
  | { phase: "frage"; typ: "start" }
  | { phase: "frage"; typ: "denkt_nach" }
  | { phase: "frage"; typ: "teil"; text: string }
  | { phase: "frage"; typ: "fertig"; text: string }
  | {
      phase: "abgeschlossen";
      geruest: string;
      ausgangslage_gespeichert: boolean;
      gesichert_als: string | null;
      neuer_ordner: string;
      kapitelplan_platzhalter: string[];
    }
  | { phase: "beendet_ohne_speichern" }
  | { phase: "fehler"; typ: "error"; text: string };

// --- Projekt-Abgleich Prod <-> lokaler PC (siehe backend/app/api/sync.py) ---

export interface SyncPartner {
  konfiguriert: boolean;
  url: string;
  username: string;
  passwort_gesetzt: boolean;
}

export interface SyncInfo {
  projekt_id: string;
  ordner: string;
  name: string;
  titel: string | null;
  epoche: string | null;
  anzahl_kapitel: number;
  hash: string;
  basis_hash: string | null;
  letzter_abgleich: string | null;
  geaendert_ts: number;
  lokal_aufraeumen: boolean;
  laufende_jobs: string[];
}

export type SyncStatus = "nur_lokal" | "nur_server" | "gleich" | "lokal_neuer" | "server_neuer" | "abweichend";

export interface SyncZeile {
  name: string;
  titel: string | null;
  epoche: string | null;
  lokal: SyncInfo | null;
  server: SyncInfo | null;
  status: SyncStatus;
  unsicher: boolean;
  nachricht: string;
  aufraeumen_vorgemerkt: boolean;
}

export interface SyncProjektStatus {
  partner_konfiguriert: boolean;
  abgeglichen: boolean;
}
