import { useCallback, useEffect, useRef, useState } from "react";
import { api } from "./api/client";
import type { EpocheKurz, ProjektDetail, ProjektKurz, SSHZiel } from "./api/types";
import { AboutDialog } from "./components/AboutDialog";
import { TabBar } from "./components/TabBar";
import { AnalysatorPage } from "./pages/AnalysatorPage";
import { ArchitektInterviewPage } from "./pages/ArchitektInterviewPage";
import { EinstellungenPage } from "./pages/EinstellungenPage";
import { EpocheErstellenPage } from "./pages/EpocheErstellenPage";
import { FundusPage } from "./pages/FundusPage";
import { GeruestPage } from "./pages/GeruestPage";
import { MobilPage } from "./pages/MobilPage";
import { OrtePage } from "./pages/OrtePage";
import { StatusFooter } from "./components/StatusFooter";
import { ZeitUeberbrueckungOverlay } from "./components/ZeitUeberbrueckungOverlay";
import { AktivitaetProvider } from "./context/AktivitaetContext";
import { KapitelTextProvider } from "./context/KapitelTextContext";
import { useAuth } from "./context/AuthContext";
import { BenutzerPage } from "./pages/BenutzerPage";
import { LoginPage } from "./pages/LoginPage";
import { ProjektePage } from "./pages/ProjektePage";
import { PersonasPage } from "./pages/PersonasPage";
import { PruefenAnwendenPage } from "./pages/PruefenAnwendenPage";
import { RechtschreibungPage } from "./pages/RechtschreibungPage";
import { SchreibenPage } from "./pages/SchreibenPage";
import { StandExportPage } from "./pages/StandExportPage";
import { Button } from "./components/ui";
import { KiZielUmschalter } from "./components/KiZielUmschalter";

// localStorage-Schluessel fuer die zuletzt im Kopfbereich gewaehlte KI-Ziel-ID.
const KI_ZIEL_SPEICHER = "ki-ziel-id";

function App() {
  const { benutzer, ladend, logout } = useAuth();
  const [projekte, setProjekte] = useState<ProjektKurz[]>([]);
  const [epochen, setEpochen] = useState<EpocheKurz[]>([]);
  const [sshZiele, setSshZiele] = useState<SSHZiel[]>([]);
  const [aktuellesProjekt, setAktuellesProjekt] = useState<string | null>(null);
  const [projektDetail, setProjektDetail] = useState<ProjektDetail | null>(null);
  const [activeTab, setActiveTab] = useState("projekte");
  const [interviewErzwungen, setInterviewErzwungen] = useState(false);
  // true nach "✨ KI entwirft das Gerüst" beim Anlegen (ProjektePage) - laesst
  // GeruestPage beim ersten Betreten direkt das KI-Entwurf-Overlay oeffnen.
  const [kiEntwurfAuto, setKiEntwurfAuto] = useState(false);
  // Geteilt ueber alle Pipeline-Schritte hinweg (Architekt, Schreiben,
  // Pruefen, Stand): das gewaehlte KI-Ziel soll beim
  // Tab-Wechsel erhalten bleiben, statt bei jedem neu gemounteten Tab auf
  // "Lokal" zurueckzufallen - das fuehrte sonst dazu, dass z.B. "Pruefen"
  // versehentlich gegen ein nicht erreichbares lokales Ollama lief, obwohl
  // im Schreiben-Tab zuvor ein SSH-Ziel gewaehlt war.
  const [sshZielId, setSshZielId] = useState("");
  const [ueberSichtbar, setUeberSichtbar] = useState(false);
  const favoritVorausgewaehlt = useRef(false);

  const projekteLaden = useCallback(() => {
    api.projekte().then(setProjekte);
  }, []);

  // Zentral hier geladen (statt in ProjektePage/EpocheErstellenPage je
  // einmal einzeln) - beide Stellen riefen bisher unabhaengig api.epochen()
  // NUR beim eigenen Mount auf: eine in EpocheErstellenPage neu angelegte
  // oder geloeschte Epoche tauchte im "Neues Projekt"-Dropdown von
  // ProjektePage deshalb erst nach einem harten Reload auf, weil dessen
  // eigener einmaliger Fetch laengst vorbei war (siehe onEpochenGeaendert
  // unten - dasselbe Prop-Callback-Muster wie onProjekteGeaendert).
  const epochenLaden = useCallback(() => {
    api.epochen().then(setEpochen);
  }, []);

  const sshZieleLaden = useCallback(() => {
    api.sshZiele().then(setSshZiele);
  }, []);

  const projektDetailLaden = useCallback(() => {
    if (aktuellesProjekt) api.projekt(aktuellesProjekt).then(setProjektDetail);
  }, [aktuellesProjekt]);

  useEffect(() => {
    // Vor dem Login (siehe useAuth() oben) macht das Laden noch keinen
    // Sinn - ist Settings.auth_aktiv im Backend an, liefen diese Aufrufe
    // sonst ins Leere (401), bevor ueberhaupt eine Session existiert.
    if (!benutzer) return;
    projekteLaden();
    epochenLaden();
    sshZieleLaden();
  }, [benutzer, projekteLaden, epochenLaden, sshZieleLaden]);

  useEffect(() => {
    projektDetailLaden();
  }, [projektDetailLaden]);

  useEffect(() => {
    // Nur EINMAL beim ersten Laden der KI-Ziele automatisch vorbelegen -
    // ein spaeter im laufenden Betrieb gesetzter/entfernter Favorit soll die
    // gerade aktive Auswahl nicht nachtraeglich unter dem Nutzer wegziehen.
    // Vorrang hat die zuletzt im Umschalter gewaehlte Wahl dieses Browsers,
    // danach der Favorit, danach das erste Ziel.
    if (favoritVorausgewaehlt.current || sshZiele.length === 0) return;
    favoritVorausgewaehlt.current = true;
    let gemerkt: string | null = null;
    try {
      gemerkt = window.localStorage.getItem(KI_ZIEL_SPEICHER);
    } catch {
      /* Speicher blockiert - dann eben Favorit */
    }
    const ziel =
      sshZiele.find((z) => z.id === gemerkt) ?? sshZiele.find((z) => z.favorit) ?? sshZiele[0];
    setSshZielId(ziel.id);
  }, [sshZiele]);

  function kiZielWaehlen(id: string) {
    setSshZielId(id);
    try {
      window.localStorage.setItem(KI_ZIEL_SPEICHER, id);
    } catch {
      /* nur Komfort - ohne Speicher gilt beim naechsten Laden der Favorit */
    }
  }

  function projektAuswaehlen(ordner: string) {
    setAktuellesProjekt(ordner);
    setInterviewErzwungen(false);
    setActiveTab("geruest");
  }

  function architektAbgeschlossen(neuerOrdner: string) {
    setInterviewErzwungen(false);
    setAktuellesProjekt(neuerOrdner);
    projekteLaden();
  }

  function ordnerUmbenannt(neuerOrdner: string) {
    setAktuellesProjekt(neuerOrdner);
    projekteLaden();
  }

  function projektGeloescht(ordner: string) {
    if (aktuellesProjekt === ordner) {
      setAktuellesProjekt(null);
      setActiveTab("projekte");
    }
    projekteLaden();
  }

  if (ladend) return null;
  if (!benutzer) return <LoginPage />;

  const tabs = [
    { id: "projekte", label: "Projekte", icon: "📚" },
    ...(aktuellesProjekt
      ? [
          { id: "geruest", label: "Architekt / Gerüst", icon: "🗺️" },
          { id: "schreiben", label: "Schreiben", icon: "✍️" },
          { id: "pruefen", label: "Prüfen & Anwenden", icon: "🔍" },
          { id: "rechtschreibung", label: "Rechtschreibung", icon: "📖" },
          { id: "stand", label: "Stand & Export", icon: "📦" },
          { id: "personas", label: "Personas", icon: "🎭" },
        ]
      : []),
    { id: "analysator", label: "Analysator", icon: "🔬" },
    { id: "epoche", label: "Epoche erstellen", icon: "🏛️" },
    { id: "fundus", label: "Personen-Fundus", icon: "🧬", align: "end" as const },
    { id: "orte", label: "Orte-Fundus", icon: "🗺️", align: "end" as const },
    // KI-Ziele verwalten, Speicherort-Einstellungen und Benutzerverwaltung
    // betreffen die gesamte Installation, nicht nur das eigene Projekt -
    // deshalb nur fuer Admin-Benutzer sichtbar (serverseitig zusaetzlich ueber
    // get_current_admin abgesichert, siehe backend/app/main.py). KI-Ziele
    // werden innerhalb von EinstellungenPage verwaltet, kein eigener Tab mehr.
    ...(benutzer.ist_admin
      ? [
          { id: "einstellungen", label: "Einstellungen", icon: "⚙️", align: "end" as const },
          { id: "benutzer", label: "Benutzer", icon: "👤", align: "end" as const },
        ]
      : []),
  ];

  return (
    <AktivitaetProvider>
    <KapitelTextProvider>
    <div className="flex h-screen flex-col overflow-hidden text-text">
      <header className="flex flex-col gap-3 border-b border-border px-4 py-3 sm:flex-row sm:flex-wrap sm:items-center sm:justify-between sm:gap-4 sm:px-6 sm:py-4">
        <div className="flex min-w-0 flex-wrap items-center gap-x-4 gap-y-1">
          <h1 className="flex shrink-0 items-center gap-2">
            <img src="/favicon.svg" alt="" className="h-8 w-8 shrink-0 rounded-lg" />
            <span className="heading-flourish inline-block bg-gradient-to-r from-accent-light to-accent bg-clip-text text-2xl font-bold tracking-tight text-transparent sm:text-3xl">
              Geschichten Erzähler
            </span>
          </h1>
          {aktuellesProjekt && (
            <span className="truncate whitespace-nowrap text-sm text-text-muted">
              Projekt: <span className="font-medium text-text">{projektDetail?.ordner ?? aktuellesProjekt}</span>
            </span>
          )}
        </div>
        <div className="flex flex-wrap items-center gap-3 sm:shrink-0">
          {aktuellesProjekt && (
            // Ein einziges KI-Ziel pro Projekt-Sitzung statt einer eigenen
            // Auswahl in jedem Pipeline-Schritt - innerhalb derselben
            // Geschichte wechselt man das praktisch nie zwischen den
            // Schritten. Umschalter statt Dropdown: z.B. Athene (langsam,
            // ueber Nacht) vs. PC (schnell, muss laufen). Ohne angelegte
            // KI-Ziele bleibt es beim lokalen Standard-Ollama.
            <KiZielUmschalter ziele={sshZiele} value={sshZielId} onChange={kiZielWaehlen} />
          )}
          <button
            onClick={() => window.open(api.anleitungUrl(), "_blank")}
            className="text-sm text-text-muted hover:text-text"
          >
            Anleitung
          </button>
          <button
            onClick={() => window.open(api.hilfeUrl(), "_blank")}
            className="text-sm text-text-muted hover:text-text"
          >
            Hilfe
          </button>
          <button onClick={() => setUeberSichtbar(true)} className="text-sm text-text-muted hover:text-text">
            Über
          </button>
          <span className="text-sm text-text-muted">{benutzer.username}</span>
          <Button variant="secondary" onClick={() => logout()}>
            Abmelden
          </Button>
        </div>
      </header>

      {/* Handy-Breite (< md) MIT offenem Projekt: statt der vollen
          Tab-Navigation (Architekt/Gerüst, Schreiben mit Volltext-Editor,
          Prüfen & Anwenden mit Monaco-Editor, ...) nur die schlanke
          MobilPage - fuer Bildschirmbreiten, auf denen aktives Schreiben
          /Editieren nicht praktikabel ist, liegt der Fokus dort auf
          Automatikmodus-Überwachung + Prüfer-Vorschläge übernehmen/leicht
          abändern (siehe MobilPage.tsx). Ohne Projekt (Projektliste,
          Analysator, ...) bleibt die normale Ansicht auch auf dem Handy
          bestehen - dafuer ist genug Platz. */}
      {aktuellesProjekt && (
        <div className="flex-1 overflow-y-auto pb-10 md:hidden">
          <MobilPage
            ordner={aktuellesProjekt}
            projekt={projektDetail}
            sshZielId={sshZielId}
            onGeaendert={() => {
              projektDetailLaden();
              projekteLaden();
            }}
          />
        </div>
      )}

      <div className={`flex flex-1 flex-col overflow-hidden ${aktuellesProjekt ? "hidden md:flex" : ""}`}>
      <TabBar tabs={tabs} active={activeTab} onSelect={setActiveTab} />

      {/* Jeder Tab-Inhalt bleibt dauerhaft gemountet und wird nur per CSS
          ein-/ausgeblendet (statt bedingt gerendert), solange dasselbe
          Projekt offen ist. Vorher wurde beim Tab-Wechsel die komplette
          Seite unmounted - dabei ging jeder lokale Zustand verloren
          (laufende Pruefung/Lektorat wirkte "abgebrochen", ein gerade
          geschriebenes Kapitel "verschwand"), obwohl der zugehoerige
          Server-Request oft noch lief oder laengst fertig war. Der
          key={aktuellesProjekt} sorgt weiterhin dafuer, dass beim
          Wechsel zu einem ANDEREN Projekt alles frisch neu gemountet
          wird (kein Ueberbleibsel des vorherigen Projekts). */}
      {/* h-screen + overflow-hidden am aeusseren Container (oben) sorgt
          dafuer, dass Kopfbereich, Tab-Leiste und Fussleiste immer fix
          sichtbar bleiben - nur dieser mittlere Bereich scrollt bei Bedarf,
          statt dass die ganze Seite scrollt. */}
      <main className="min-h-0 flex-1 overflow-y-auto pb-10 lg:overflow-hidden">
        <div className={activeTab === "projekte" ? "lg:h-full" : "hidden"}>
          <ProjektePage
            projekte={projekte}
            epochen={epochen}
            aktuellesProjekt={aktuellesProjekt}
            onProjekteGeaendert={projekteLaden}
            onEpochenGeaendert={epochenLaden}
            onProjektAuswaehlen={projektAuswaehlen}
            onProjektGeloescht={projektGeloescht}
            onNeuSchreibenGestartet={projektAuswaehlen}
            onKiEntwurfGestartet={(ordner) => {
              projekteLaden();
              projektAuswaehlen(ordner);
              setKiEntwurfAuto(true);
            }}
          />
        </div>

        {aktuellesProjekt && (
          <div key={aktuellesProjekt} className="contents">
            <div className={activeTab === "geruest" ? "lg:h-full" : "hidden"}>
              {interviewErzwungen || !projektDetail?.geruest ? (
                <ArchitektInterviewPage
                  ordner={aktuellesProjekt}
                  sshZielId={sshZielId}
                  onAbgeschlossen={architektAbgeschlossen}
                />
              ) : (
                <GeruestPage
                  ordner={aktuellesProjekt}
                  projekt={projektDetail}
                  onGeaendert={() => {
                    projektDetailLaden();
                    projekteLaden();
                  }}
                  onOrdnerUmbenannt={ordnerUmbenannt}
                  onInterviewStarten={() => setInterviewErzwungen(true)}
                  onNeuSchreibenGestartet={(neuerOrdner) => {
                    projekteLaden();
                    projektAuswaehlen(neuerOrdner);
                  }}
                  aktiv={activeTab === "geruest"}
                  sshZielId={sshZielId}
                  kiEntwurfAuto={kiEntwurfAuto}
                  onKiEntwurfAutoVerbraucht={() => setKiEntwurfAuto(false)}
                />
              )}
            </div>

            <div className={activeTab === "schreiben" ? "lg:h-full" : "hidden"}>
              <SchreibenPage
                ordner={aktuellesProjekt}
                projekt={projektDetail}
                sshZielId={sshZielId}
                aktiv={activeTab === "schreiben"}
                onKapitelGeschrieben={() => {
                  projektDetailLaden();
                  projekteLaden();
                }}
              />
            </div>

            <div className={activeTab === "pruefen" ? "lg:h-full" : "hidden"}>
              <PruefenAnwendenPage
                ordner={aktuellesProjekt}
                projekt={projektDetail}
                sshZielId={sshZielId}
                aktiv={activeTab === "pruefen"}
                onLokalEntfernt={projektGeloescht}
                onGeaendert={() => {
                  projektDetailLaden();
                  projekteLaden();
                }}
              />
            </div>

            <div className={activeTab === "rechtschreibung" ? "lg:h-full" : "hidden"}>
              <RechtschreibungPage
                ordner={aktuellesProjekt}
                projekt={projektDetail}
                sshZielId={sshZielId}
              />
            </div>

            <div className={activeTab === "stand" ? "lg:h-full" : "hidden"}>
              <StandExportPage
                ordner={aktuellesProjekt}
                projekt={projektDetail}
                sshZielId={sshZielId}
                sshZiele={sshZiele}
                onGeaendert={() => {
                  projektDetailLaden();
                  projekteLaden();
                }}
              />
            </div>

            <div className={activeTab === "personas" ? "lg:h-full" : "hidden"}>
              <PersonasPage ordner={aktuellesProjekt} />
            </div>
          </div>
        )}

        <div className={activeTab === "analysator" ? "lg:h-full" : "hidden"}>
          <AnalysatorPage
            epochen={epochen}
            sshZielId={sshZielId}
            onProjektErzeugt={projektAuswaehlen}
            onEpochenGeaendert={epochenLaden}
          />
        </div>

        <div className={activeTab === "epoche" ? "lg:h-full" : "hidden"}>
          <EpocheErstellenPage epochen={epochen} onEpochenGeaendert={epochenLaden} />
        </div>

        <div className={activeTab === "fundus" ? "lg:h-full" : "hidden"}>
          <FundusPage sshZielId={sshZielId} epochen={epochen} />
        </div>

        <div className={activeTab === "orte" ? "lg:h-full" : "hidden"}>
          <OrtePage epochen={epochen} />
        </div>

        {benutzer.ist_admin && (
          <>
            <div className={activeTab === "einstellungen" ? "lg:h-full" : "hidden"}>
              <EinstellungenPage sshZiele={sshZiele} onSshZieleGeaendert={sshZieleLaden} />
            </div>

            <div className={activeTab === "benutzer" ? "lg:h-full" : "hidden"}>
              <BenutzerPage />
            </div>
          </>
        )}
      </main>
      </div>
      <StatusFooter />
      <ZeitUeberbrueckungOverlay />
      {ueberSichtbar && <AboutDialog onClose={() => setUeberSichtbar(false)} />}
    </div>
    </KapitelTextProvider>
    </AktivitaetProvider>
  );
}

export default App;
