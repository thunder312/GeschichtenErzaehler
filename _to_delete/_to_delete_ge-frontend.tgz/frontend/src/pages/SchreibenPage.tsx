import { useEffect, useRef, useState } from "react";
import { api, schreibenWebSocketUrl } from "../api/client";
import type {
  AutomatikFortsetzenVorschau,
  AutomatikStatus,
  AutomatikVerlaufEintrag,
  BefundeAntwort,
  Finding,
  HostStatus,
  ProjektDetail,
  SchreibenNachricht,
} from "../api/types";
import { BefundListe } from "../components/BefundListe";
import { CollapsibleCard } from "../components/CollapsibleCard";
import { FindingsList } from "../components/FindingsList";
import { SpeicherkontrolleDialog, SpeicherkontrolleWiederhochBanner } from "../components/SpeicherkontrolleDialog";
import { Button, Card, CardTitle, Input, Label, Select, Textarea } from "../components/ui";
import { useAktivitaet } from "../context/AktivitaetContext";
import { automatikAktionsText, hatReste, resteZusammenfassen } from "../utils/automatik";
import { alsDateiHerunterladen } from "../utils/download";
import {
  fertigSoundAbspielen, gewaehlterSound, SOUND_LISTE, soundFreischalten, soundWaehlen,
} from "../utils/fertigSound";

interface SchreibenPageProps {
  ordner: string;
  projekt: ProjektDetail | null;
  sshZielId: string;
  onKapitelGeschrieben: () => void;
  aktiv: boolean;
}

// Grund-Codes aus app/core/automatik.py:befunde_anwenden() - lesbare Texte
// statt der rohen Codes in der Zusammenfassung/Protokollliste.
const GRUND_LABEL: Record<string, string> = {
  kein_vorschlag: "kein Korrekturvorschlag (unsicher)",
  konflikt: "widersprüchliche Vorschläge zweier Prüfer",
  nicht_gefunden: "Textstelle nicht mehr auffindbar",
  verdaechtiger_vorschlag: "verdächtiger Vorschlag verworfen",
};

function formatDauer(sekunden: number): string {
  const std = Math.floor(sekunden / 3600);
  const min = Math.round((sekunden % 3600) / 60);
  return std > 0 ? `${std} Std. ${min} Min.` : `${min} Min.`;
}


export function SchreibenPage({
  ordner,
  projekt,
  sshZielId,
  onKapitelGeschrieben,
  aktiv,
}: SchreibenPageProps) {
  const [n, setN] = useState(1);
  const [zusatzhinweis, setZusatzhinweis] = useState("");
  const [laeuft, setLaeuft] = useState(false);
  const [denktNach, setDenktNach] = useState(false);
  const [autorText, setAutorText] = useState("");
  const [geladenAusDatei, setGeladenAusDatei] = useState(false);
  const [modell, setModell] = useState<string | null>(null);
  const [befunde, setBefunde] = useState<BefundeAntwort | null>(null);
  const [findings, setFindings] = useState<Finding[]>([]);
  const [phase, setPhase] = useState<string | null>(null);
  const [fehler, setFehler] = useState<string | null>(null);
  const [reloadToken, setReloadToken] = useState(0);
  // Feature "KI- und Speicherkontrolle": Rückfrage VOR jedem Start (interaktiv,
  // Automatik, "Bestätige alles") - "Bild-Container herunterfahren?". Rein
  // clientseitig: der Dialog wird per Promise aufgelöst, dann startet der
  // eigentliche Ablauf.
  const [skDialog, setSkDialog] = useState<{
    status: HostStatus;
    entscheiden: (herunterfahren: boolean) => void;
  } | null>(null);
  const [skLaeuft, setSkLaeuft] = useState(false);
  // Beim interaktiven Schreiben heruntergefahrene Container - für ein
  // "wieder hochfahren?"-Banner nach dem Kapitel (beim Automatik kommt das
  // aus automatikStatus.speicherkontrolle_gestoppt).
  const [skInteraktivGestoppt, setSkInteraktivGestoppt] = useState<string[]>([]);
  const socketRef = useRef<WebSocket | null>(null);
  const letztesProjekt = useRef<string | null>(null);
  const autoVorgeschlageneNummerRef = useRef<number | null>(null);
  const phaseRef = useRef<string | null>(null);
  const { starten: aktivitaetStarten, beenden: aktivitaetBeenden } = useAktivitaet();

  const [automatikStatus, setAutomatikStatus] = useState<AutomatikStatus | null>(null);
  const [automatikMaxDurchlaeufe, setAutomatikMaxDurchlaeufe] = useState(3);
  const [automatikFehler, setAutomatikFehler] = useState<string | null>(null);
  const [automatikVerlauf, setAutomatikVerlauf] = useState<AutomatikVerlaufEintrag[]>([]);
  const [vorschau, setVorschau] = useState<AutomatikFortsetzenVorschau | null>(null);
  const [vorschauLaden, setVorschauLaden] = useState(false);
  const [vorschauFehler, setVorschauFehler] = useState<string | null>(null);
  // Optionen "Nach Fertigstellung": Sound wird gemerkt, Herunterfahren bewusst
  // NICHT (muss pro Lauf neu gewaehlt werden).
  const [fertigSound, setFertigSoundState] = useState(() => {
    try {
      return localStorage.getItem("automatikFertigSound") === "1";
    } catch {
      return false;
    }
  });
  const [fertigHerunterfahren, setFertigHerunterfahren] = useState(false);
  const [soundId, setSoundIdState] = useState(gewaehlterSound);
  function setSoundId(id: string) {
    setSoundIdState(id);
    soundWaehlen(id);
    soundFreischalten();
    fertigSoundAbspielen(id); // direkt vorhoeren
  }
  const [herunterfahrenFehler, setHerunterfahrenFehler] = useState<string | null>(null);
  const [jetztMs, setJetztMs] = useState(() => Date.now());
  function setFertigSound(an: boolean) {
    setFertigSoundState(an);
    try {
      localStorage.setItem("automatikFertigSound", an ? "1" : "0");
    } catch {
      /* ohne Speicher einfach nicht merken */
    }
    if (an) soundFreischalten();
  }
  const automatikLiefZuvorRef = useRef(false);
  const automatikAktivitaetTextRef = useRef<string | null>(null);

  function automatikVerlaufLaden() {
    api
      .automatikVerlauf(ordner)
      .then(setAutomatikVerlauf)
      .catch(() => {});
  }

  // Pollt den Automatikmodus-Status, solange dieser Tab offen ist - der Lauf
  // selbst haengt NICHT an dieser Verbindung (Hintergrund-Job auf dem
  // Server, siehe app/api/pipeline.py:_automatik_lauf), das Polling zeigt
  // nur den jeweils aktuellen Stand an.
  useEffect(() => {
    let abgebrochen = false;
    automatikLiefZuvorRef.current = false;
    automatikVerlaufLaden();
    function laden() {
      api
        .automatikStatus(ordner)
        .then((status) => {
          if (abgebrochen) return;
          setAutomatikStatus(status);
          // Sobald ein Lauf zu Ende geht (egal ob abgeschlossen, mit
          // Fehler oder gestoppt), ist ein neuer Eintrag in der
          // Verlaufsdatei dazugekommen (siehe app/core/automatik.py:
          // verlauf_eintrag_anhaengen) - genau dann neu laden statt bei
          // jedem 4-Sekunden-Tick.
          if (automatikLiefZuvorRef.current && !status.laeuft) {
            automatikVerlaufLaden();
            // Signalton nur, wenn der Lauf sauber fertig wurde (alle Kapitel
            // geschrieben und geprueft) - nicht bei Stopp oder Fehler.
            if (status.abgeschlossen && status.nach_fertig_sound) fertigSoundAbspielen();
          }
          automatikLiefZuvorRef.current = status.laeuft;

          // Spiegelt den Automatikmodus-Fortschritt in die globale
          // Fusszeile (StatusFooter) - sonst zeigt die immer "Bereit",
          // waehrend im Hintergrund ein stundenlanger Lauf werkelt. Nur bei
          // TEXT-Aenderung neu "starten()" (das setzt die Sekunden-Uhr in
          // der Fusszeile auf 0 zurueck) statt bei jedem 4-Sekunden-Tick,
          // damit man sieht, wie lange der aktuelle Schritt schon laeuft.
          if (status.laeuft) {
            const text = automatikAktionsText(status);
            if (automatikAktivitaetTextRef.current !== text) {
              automatikAktivitaetTextRef.current = text;
              aktivitaetStarten(text);
            }
          } else if (automatikAktivitaetTextRef.current !== null) {
            automatikAktivitaetTextRef.current = null;
            aktivitaetBeenden();
          }
        })
        .catch(() => {});
    }
    laden();
    const intervall = setInterval(laden, 4000);
    return () => {
      abgebrochen = true;
      clearInterval(intervall);
    };
  }, [ordner]);

  /** Fragt den KI-Host-Status ab und zeigt bei Speicherdruck den Dialog.
   * Liefert die Liste der (auf Nutzer-Wunsch) heruntergefahrenen Container -
   * leer, wenn nichts nötig/gewünscht oder das KI-Ziel nicht steuerbar ist. */
  function speicherkontrollePruefen(): Promise<string[]> {
    if (!sshZielId) return Promise.resolve([]);
    return api
      .hostStatus(sshZielId)
      .then((status) => {
        if (!status.verfuegbar || !status.herunterfahren_empfohlen) return [];
        return new Promise<string[]>((resolve) => {
          setSkDialog({
            status,
            entscheiden: async (herunterfahren: boolean) => {
              if (!herunterfahren) {
                setSkDialog(null);
                resolve([]);
                return;
              }
              setSkLaeuft(true);
              const gestoppt: string[] = [];
              for (const c of status.containers.filter((x) => x.running)) {
                try {
                  await api.hostContainer(sshZielId, c.name, "stop");
                  gestoppt.push(c.name);
                } catch {
                  // defensiv: einzelner Fehlschlag stoppt den Start nicht
                }
              }
              setSkLaeuft(false);
              setSkDialog(null);
              resolve(gestoppt);
            },
          });
        });
      })
      .catch(() => []);
  }

  async function automatikStarten(fortsetzen = false, automatischBestaetigen = false, nurNeueKapitel = false) {
    setAutomatikFehler(null);
    // Muss synchron im Klick-Handler passieren (Autoplay-Regel der Browser).
    if (fertigSound) soundFreischalten();
    const gestoppt = await speicherkontrollePruefen();
    try {
      await api.automatikStarten(
        ordner, automatikMaxDurchlaeufe, sshZielId || null, fortsetzen, automatischBestaetigen, nurNeueKapitel,
        gestoppt, fertigSound, fertigHerunterfahren && (automatikStatus?.herunterfahren_moeglich ?? false),
      );
      setVorschau(null);
      setAutomatikStatus(await api.automatikStatus(ordner));
    } catch (e) {
      setAutomatikFehler(e instanceof Error ? e.message : String(e));
    }
  }

  async function ladeVorschau() {
    setVorschauFehler(null);
    setVorschauLaden(true);
    try {
      setVorschau(await api.automatikFortsetzenVorschau(ordner));
    } catch (e) {
      setVorschauFehler(e instanceof Error ? e.message : String(e));
    } finally {
      setVorschauLaden(false);
    }
  }

  const herunterfahrenGeplantBis = automatikStatus?.herunterfahren_geplant_bis ?? null;
  const herunterfahrenRest =
    herunterfahrenGeplantBis != null ? Math.max(0, Math.ceil(herunterfahrenGeplantBis - jetztMs / 1000)) : 0;
  useEffect(() => {
    if (herunterfahrenGeplantBis == null) return;
    setJetztMs(Date.now());
    const t = setInterval(() => setJetztMs(Date.now()), 1000);
    return () => clearInterval(t);
  }, [herunterfahrenGeplantBis]);

  async function herunterfahrenAbbrechen() {
    setHerunterfahrenFehler(null);
    try {
      await api.automatikHerunterfahrenAbbrechen(ordner);
    } catch (e) {
      setHerunterfahrenFehler(e instanceof Error ? e.message : String(e));
    }
    setAutomatikStatus(await api.automatikStatus(ordner));
  }

  async function automatikStoppen() {
    await api.automatikStoppen(ordner);
    setAutomatikStatus(await api.automatikStatus(ordner));
  }

  useEffect(() => {
    // Kapitelnummer nur beim WECHSEL des Projekts neu vorschlagen, nicht bei
    // jeder Aktualisierung von projekt (sonst ueberschreibt jede erneute
    // Detail-Ladung eine bereits vom Nutzer getippte Kapitelnummer).
    if (projekt && letztesProjekt.current !== projekt.ordner) {
      letztesProjekt.current = projekt.ordner;
      setN((projekt.kapitel.length || 0) + 1);
    }
  }, [projekt]);

  useEffect(() => () => socketRef.current?.close(), []);

  // Zeigt beim (erneuten) Betreten dieses Tabs bzw. bei einer anderen
  // Kapitelnummer den bereits gespeicherten Kapiteltext an, statt immer
  // leer zu starten - vorher wirkte ein schon geschriebenes Kapitel nach
  // einem Tab-Wechsel "verschwunden", obwohl kapitel_NN.md unveraendert auf
  // der Platte lag (die Anzeige war reiner, nicht persistenter React-State).
  useEffect(() => {
    if (laeuft) return;
    // Direkt nach erfolgreichem Abschluss zeigt "starten()" bereits den
    // frisch geschriebenen Text an, und die Kapitelnummer wurde automatisch
    // auf das naechste (noch nicht existierende) Kapitel hochgezaehlt (siehe
    // "abgeschlossen"-Handler unten). Ohne diese Absicherung wuerde dieser
    // Effekt feuern, sehen dass das NEUE n noch keine Datei hat, und den
    // gerade erst angezeigten, bereits gespeicherten Text wieder leeren -
    // wirkte wie "Kapiteltext verschwindet nach dem Schreiben", obwohl
    // kapitel_NN.md korrekt auf der Platte liegt. Bewusst KEIN einmaliges
    // Verbrauchen des Flags (z.B. per Reset auf false direkt hier): der
    // Effekt haengt auch an "projekt", das durch onKapitelGeschrieben() erst
    // ASYNCHRON (verzoegert, nach diesem ersten Durchlauf) aktualisiert wird
    // und den Effekt dadurch ein zweites Mal feuert - der Vergleich gegen n
    // bleibt deshalb so lange gueltig, bis der Nutzer die Nummer tatsaechlich
    // manuell auf einen anderen Wert aendert.
    if (autoVorgeschlageneNummerRef.current === n) {
      return;
    }
    let abgebrochen = false;
    setFehler(null);
    if (!projekt?.kapitel.includes(n)) {
      setAutorText("");
      setBefunde(null);
      setGeladenAusDatei(false);
      return;
    }
    api
      .kapitel(ordner, n)
      .then((text) => {
        // Ohne diese Absicherung konnte eine noch laufende, aber
        // ueberholte Anfrage (z.B. fuer die vorherige Kapitelnummer) nach
        // dem Wechsel auf eine neue Nummer verspaetet zurueckkommen und
        // den korrekt zurueckgesetzten Zustand wieder mit dem falschen
        // Kapiteltext ueberschreiben.
        if (abgebrochen) return;
        setAutorText(text);
        setGeladenAusDatei(true);
      })
      .catch(() => {
        if (abgebrochen) return;
        setAutorText("");
        setGeladenAusDatei(false);
      });
    api
      .befunde(ordner, n)
      .then((text) => {
        if (!abgebrochen) setBefunde(text);
      })
      .catch(() => {
        if (!abgebrochen) setBefunde(null);
      });
    return () => {
      abgebrochen = true;
    };
  }, [ordner, n, projekt, laeuft, reloadToken]);

  // Betritt der Nutzer diesen Tab erneut (z.B. weil im Hintergrund der
  // Automatikmodus weitergeschrieben/geprueft hat, oder weil in "Pruefen &
  // Anwenden" manuelle Korrekturen an kapitel_NN.md gespeichert wurden),
  // den Kapiteltext/die Befunde fuer die aktuell gewaehlte Nummer frisch von
  // der Platte laden - analog zum bestehenden Nachlade-Fix in
  // PruefenAnwendenPage.tsx (dort ueber "aktiv"-Prop + reloadToken). Ohne das
  // zeigte das "Autor"-Fenster nach einem Tab-Wechsel weiterhin den Stand vom
  // letzten Besuch, auch wenn die Datei sich laengst geaendert hatte.
  const warAktiv = useRef(aktiv);
  useEffect(() => {
    const wurdeBetreten = aktiv && !warAktiv.current;
    warAktiv.current = aktiv;
    if (!wurdeBetreten || laeuft) return;
    onKapitelGeschrieben();
    setReloadToken((t) => t + 1);
  }, [aktiv, laeuft, onKapitelGeschrieben]);

  async function starten() {
    const gestoppt = await speicherkontrollePruefen();
    setSkInteraktivGestoppt(gestoppt);

    setLaeuft(true);
    setAutorText("");
    setGeladenAusDatei(false);
    setBefunde(null);
    setFindings([]);
    setFehler(null);
    setPhase("autor");
    phaseRef.current = "autor";
    setModell(null);

    const socket = new WebSocket(schreibenWebSocketUrl(ordner, n, zusatzhinweis, sshZielId || null));
    socketRef.current = socket;

    aktivitaetStarten(`Schreibt Kapitel ${n}...`);

    socket.onmessage = (ereignis) => {
      const nachricht: SchreibenNachricht = JSON.parse(ereignis.data);
      setPhase(nachricht.phase);
      phaseRef.current = nachricht.phase;
      if (nachricht.phase === "autor") {
        if (nachricht.typ === "start") setModell(nachricht.modell);
        if (nachricht.typ === "thinking") setDenktNach(true);
        if (nachricht.typ === "content") {
          setDenktNach(false);
          setAutorText((bisher) => bisher + nachricht.text);
        }
        if (nachricht.typ === "done") setDenktNach(false);
        if (nachricht.typ === "error") setFehler(nachricht.text);
      }
      if (nachricht.phase === "nachbearbeitung" && nachricht.typ === "done") {
        setFindings(nachricht.findings);
      }
      if (nachricht.phase === "pruefen" && nachricht.typ === "start") {
        aktivitaetStarten(`Prüft Kapitel ${n} auf Anachronismen, Stimmigkeit, Kontinuität & Lektorat...`);
      }
      if (nachricht.phase === "pruefen" && nachricht.typ === "done") {
        setBefunde(nachricht.befunde);
      }
      if (nachricht.phase === "abgeschlossen") {
        setLaeuft(false);
        aktivitaetBeenden();
        onKapitelGeschrieben();
        // Nach erfolgreichem Schreiben automatisch zum naechsten Kapitel
        // weiterschalten - sonst blieb die Kapitelnummer auf dem gerade
        // geschriebenen Kapitel stehen (die Nummer wird bewusst NICHT bei
        // jeder Projekt-Aktualisierung neu vorgeschlagen, siehe Kommentar
        // oben), und ein zweiter Klick auf "Schreiben starten" ohne manuelle
        // Anpassung schrieb versehentlich dasselbe Kapitel nochmal (statt
        // das naechste), was wie ein "haengengebliebenes" Fortschreiben
        // aussah.
        autoVorgeschlageneNummerRef.current = n + 1;
        setN(n + 1);
      }
      if (nachricht.phase === "fehler") {
        setFehler(nachricht.text);
        setLaeuft(false);
        aktivitaetBeenden();
      }
    };
    socket.onerror = () => {
      setFehler("WebSocket-Verbindung fehlgeschlagen.");
      setLaeuft(false);
      aktivitaetBeenden();
    };
    socket.onclose = () => {
      // Verbindung ist weg, OHNE dass "abgeschlossen" oder "fehler" das schon
      // erklaert hat - z.B. ein Netzwerk-/Tunnel-Aussetzer mitten in der
      // Generierung (haeufigste bekannte Ursache: instabile Strecke zum
      // entfernten KI-Ziel). Ohne diese Behandlung wirkte das wie
      // "Kapiteltext verschwindet nach dem Schreiben": der Reload-Effekt
      // sah beim naechsten Durchlauf (laeuft wird false), dass fuer dieses
      // Kapitel noch keine Datei existiert (sie wurde ja nie fertig und nie
      // gespeichert), und leerte den bereits generierten Text kommentarlos.
      if (phaseRef.current !== "abgeschlossen" && phaseRef.current !== "fehler") {
        setFehler(
          "Verbindung während des Schreibens unerwartet verloren (z.B. Netzwerk-/Tunnel-Aussetzer zum KI-Ziel). " +
            "Das Kapitel wurde NICHT gespeichert. Der bisher generierte Text bleibt unten sichtbar - einfach erneut versuchen.",
        );
        // Verhindert, dass der separate "Lade gespeichertes Kapitel"-Effekt
        // (reagiert auf laeuft-Wechsel) den gerade sichtbaren, unvollstaendigen
        // Text sofort wieder loescht, nur weil kapitel_NN.md nie geschrieben
        // wurde.
        autoVorgeschlageneNummerRef.current = n;
      }
      setLaeuft(false);
      aktivitaetBeenden();
    };
  }

  function abbrechen() {
    socketRef.current?.close();
    setLaeuft(false);
    aktivitaetBeenden();
  }

  const zielWoerter = projekt?.kapitelplan[n];

  // Das "Autor"-Fenster zeigt waehrend des interaktiven Schreibens den per
  // WebSocket gestreamten Text (autorText). Laeuft stattdessen gerade der
  // Automatikmodus in PHASE "schreiben" (kein WebSocket, siehe
  // _automatik_on_event im Backend), zeigt es dessen periodisch
  // aktualisierten aktueller_text - sonst bliebe das Fenster ab dem ersten
  // unbeaufsichtigten Kapitel fuer immer leer. In jeder anderen Automatik-
  // Phase (z.B. "pruefen") wird aktueller_text vom Backend NICHT mehr
  // aktualisiert - er bliebe sonst dauerhaft auf dem zuletzt geschriebenen
  // Kapitel stehen, selbst wenn laengst ein anderes Kapitel geprueft wird
  // oder der Nutzer zwischenzeitlich manuelle Korrekturen gespeichert hat
  // (Live-Meldung 2026-09-02). Stattdessen zeigt es dann autorText, das per
  // Lade-Effekt oben (inkl. Tab-Neubetreten) den aktuellen Datei-Stand des
  // gewaehlten Kapitels n von der Platte haelt.
  const automatikSchreibtGerade = (automatikStatus?.laeuft ?? false) && !laeuft;
  const automatikStreamtGerade = automatikSchreibtGerade && automatikStatus?.phase === "schreiben";
  const angezeigterAutorText = automatikStreamtGerade ? automatikStatus?.aktueller_text ?? "" : autorText;

  // "Weitere Kapitel schreiben" nur anbieten, wenn die Geschichte schon
  // begonnen ist (mindestens ein Kapitel geschrieben) UND der Kapitelplan
  // eine noch ungeschriebene Kapitelnummer enthaelt - also genau der Fall
  // "Gerüst um ein Kapitel erweitert, jetzt nur dieses schreiben lassen".
  const geplantBis = projekt?.letztes_geplantes_kapitel ?? null;
  const geschriebeneKapitel = projekt?.kapitel ?? [];
  const naechsteLuecke = (() => {
    if (!geplantBis) return null;
    let k = 1;
    while (k <= geplantBis && geschriebeneKapitel.includes(k)) k += 1;
    return k <= geplantBis ? k : null;
  })();
  const kannErweitern =
    !automatikStatus?.laeuft && geschriebeneKapitel.length > 0 && naechsteLuecke != null;

  return (
    <div className="seite grid grid-cols-1 gap-6 p-4 sm:p-6 lg:grid-cols-[minmax(0,1fr)_minmax(0,2fr)] lg:grid-rows-[minmax(0,max-content)_auto]! lg:content-start">
      {skDialog && (
        <SpeicherkontrolleDialog
          status={skDialog.status}
          wirdAusgefuehrt={skLaeuft}
          onHerunterfahren={() => skDialog.entscheiden(true)}
          onWeiter={() => skDialog.entscheiden(false)}
        />
      )}
      {!laeuft && skInteraktivGestoppt.length > 0 && (
        <div className="lg:col-span-2">
          <SpeicherkontrolleWiederhochBanner
            key={skInteraktivGestoppt.join(",")}
            container={skInteraktivGestoppt}
            zielId={sshZielId || null}
          />
        </div>
      )}
      <div className="space-y-4">
        <Card className="h-fit space-y-3">
          <CardTitle>✍️ Kapitel schreiben</CardTitle>
          <div>
            <Label>Kapitelnummer</Label>
            <Input type="number" min={1} value={n} onChange={(e) => setN(Number(e.target.value))} disabled={laeuft} />
            {zielWoerter && <p className="mt-1 text-xs text-text-muted">Zielumfang laut Gerüst: ~{zielWoerter} Wörter</p>}
            {!zielWoerter && !!projekt?.letztes_geplantes_kapitel && n > projekt.letztes_geplantes_kapitel && (
              <p className="mt-1 text-xs text-text-muted">
                Kapitel {n} ist im Kapitelplan nicht vorgesehen (geplant bis Kapitel{" "}
                {projekt.letztes_geplantes_kapitel}) - es wird ohne festen Zielumfang geschrieben. Nutze bei
                Bedarf den Hinweis unten, um vorzugeben, was in diesem Kapitel passieren soll.
              </p>
            )}
            {projekt?.kapitel.includes(n) && (
              <p className="mt-1 text-xs text-amber-300">
                Kapitel {n} wurde bereits geschrieben - "Schreiben starten" überschreibt es (alte Fassung wird
                als .bak gesichert).
              </p>
            )}
          </div>
          <div>
            <Label>Zusätzlicher Hinweis (nur für diesen Versuch)</Label>
            <Textarea
              rows={4}
              value={zusatzhinweis}
              onChange={(e) => setZusatzhinweis(e.target.value)}
              disabled={laeuft}
              placeholder="z.B. bei starken Kontinuitäts-Brüchen im letzten Versuch..."
            />
          </div>
          {!laeuft ? (
            <Button onClick={starten} className="w-full">
              Schreiben starten
            </Button>
          ) : (
            <Button onClick={abbrechen} variant="danger" className="w-full">
              Abbrechen
            </Button>
          )}
          {fehler && <p className="text-sm text-red-400">{fehler}</p>}
        </Card>

      </div>

      <div className="space-y-4">
        <Card>
          <div className="mb-2 flex items-center justify-between">
            <h2 className="font-heading text-lg font-semibold tracking-wide text-text">
              Autor {modell && <span className="font-sans font-normal text-text-muted">({modell})</span>}
            </h2>
            {denktNach && <span className="text-xs italic text-accent-light">denkt nach...</span>}
            {automatikSchreibtGerade && automatikStatus && (
              <span className="text-xs italic text-accent-light">{automatikAktionsText(automatikStatus)}</span>
            )}
            {!laeuft && !automatikSchreibtGerade && geladenAusDatei && (
              <span className="text-xs text-text-muted">📄 gespeicherter Stand von kapitel_{String(n).padStart(2, "0")}.md</span>
            )}
            {phase && phase !== "autor" && laeuft && (
              <span className="text-xs text-text-muted">Phase: {phase}</span>
            )}
            {!laeuft && !automatikSchreibtGerade && autorText && (
              <button
                onClick={() => alsDateiHerunterladen(`kapitel_${String(n).padStart(2, "0")}.md`, autorText)}
                className="text-xs text-accent-light hover:underline"
              >
                ⬇️ Herunterladen
              </button>
            )}
          </div>
          <pre className="max-h-[420px] overflow-auto whitespace-pre-wrap rounded-lg bg-bg p-3 text-sm leading-relaxed text-text">
            {angezeigterAutorText ||
              (automatikSchreibtGerade ? "Automatikmodus startet gerade..." : "Noch kein Text erzeugt.")}
          </pre>
        </Card>

        {findings.length > 0 && (
          <Card>
            <CardTitle>🛡️ Automatische Sicherheitsnetze</CardTitle>
            <FindingsList findings={findings} />
          </Card>
        )}

        {befunde && (
          <Card>
            <CardTitle>🔍 Befunde der Prüfer (Anachronismen, Stimmigkeit &amp; Kontinuität)</CardTitle>
            <BefundListe befunde={befunde.befunde} />
          </Card>
        )}
      </div>

      <div className="space-y-3 lg:col-span-2 lg:max-h-[45vh]">
      {!automatikStatus?.laeuft &&
        automatikStatus != null &&
        automatikStatus.protokoll.length > 0 &&
        hatReste(automatikStatus.protokoll) &&
        !automatikStatus.abgeschlossen && (
          <div className="rounded-lg border border-amber-400/40 bg-amber-400/10 px-4 py-3 text-sm text-amber-300">
            ⏸️ Automatikmodus angehalten: ungelöste Prüfer-Funde seit Laufbeginn vorhanden. Im Tab "Prüfen &amp;
            Anwenden" durchsehen, bevor du mit "Fortsetzen" weitermachst - sonst häufen sich ungelöste
            Kontinuitätsprobleme über weitere Kapitel hinweg an.
          </div>
        )}

      <div className="grid grid-cols-1 items-start gap-3 lg:grid-cols-[repeat(3,minmax(0,1fr))]">
      <CollapsibleCard title="🤖 Automatikmodus" defaultOffen={false}>
        <div className="p-4">
        <p className="mb-3 text-xs text-text-muted">
          Schreibt alle noch fehlenden Kapitel am Stück und wendet danach für jedes Kapitel automatisch alle
          eindeutigen Prüfer-Korrekturen an. Widersprüchliche Vorschläge und nicht auffindbare Stellen werden
          übersprungen und bleiben wie gewohnt im Tab "Prüfen &amp; Anwenden" zur manuellen Entscheidung.
          Rechtschreibung (hunspell) läuft mit, unbekannte Wörter landen nur im Protokoll (keine automatische
          Ersetzung). Läuft im Hintergrund weiter, auch wenn du diesen Tab schließt oder den Browser zumachst.
        </p>

        {kannErweitern && (
          <div className="mb-4 rounded-lg border border-border bg-bg p-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <h3 className="font-heading text-sm font-semibold text-text">➕ Weitere Kapitel schreiben</h3>
              <Button variant="secondary" onClick={ladeVorschau} disabled={vorschauLaden}>
                {vorschauLaden ? "..." : vorschau ? "Vorschau aktualisieren" : "Vorschau laden"}
              </Button>
            </div>
            <p className="mt-1 text-xs text-text-muted">
              Für eine begonnene Geschichte, die du im Gerüst um ein Kapitel erweitert hast: Es wird nur das
              nächste ungeschriebene Kapitel geschrieben, geprüft und (bei eindeutigen Funden) korrigiert.
              Bereits fertige Kapitel werden dabei <strong>nicht</strong> erneut geprüft oder verändert.
            </p>
            {vorschauFehler && <p className="mt-2 text-sm text-red-400">{vorschauFehler}</p>}
            {vorschau && vorschau.naechstes_kapitel == null && (
              <p className="mt-2 text-sm text-text-muted">Alle geplanten Kapitel sind bereits geschrieben.</p>
            )}
            {vorschau && vorschau.naechstes_kapitel != null && (
              <div className="mt-3 space-y-2 text-sm text-text">
                <p>
                  Geplant bis Kapitel <strong>{vorschau.geplant_bis}</strong> · geschrieben:{" "}
                  {vorschau.geschrieben.join(", ") || "–"} · wird jetzt geschrieben:{" "}
                  <strong>Kapitel {vorschau.zu_schreiben.join(", ")}</strong>
                </p>
                {vorschau.anknuepfpunkt ? (
                  <div className="rounded-lg border border-border bg-surface p-2">
                    <p className="text-xs text-text-muted">
                      Anknüpfpunkt für Kapitel {vorschau.naechstes_kapitel}: „Stand nach Kapitel{" "}
                      {vorschau.anknuepfpunkt.kapitel}“
                    </p>
                    {vorschau.anknuepfpunkt.stand_vorhanden ? (
                      <>
                        <pre className="mt-1 max-h-48 overflow-auto whitespace-pre-wrap rounded bg-bg p-2 text-xs leading-relaxed text-text-muted">
                          {vorschau.anknuepfpunkt.stand_text}
                        </pre>
                        {vorschau.anknuepfpunkt.stand_veraltet && (
                          <p className="mt-1 text-xs text-amber-300">
                            ⚠ Kapitel {vorschau.anknuepfpunkt.kapitel} wurde nach dieser Zusammenfassung
                            geändert. War die Änderung inhaltlich relevant, erzeuge den Stand für Kapitel{" "}
                            {vorschau.anknuepfpunkt.kapitel} im Tab „Stand &amp; Export“ neu, bevor du
                            fortfährst.
                          </p>
                        )}
                      </>
                    ) : (
                      <p className="mt-1 text-xs text-amber-300">
                        Für Kapitel {vorschau.anknuepfpunkt.kapitel} gibt es noch keine Stand-Datei – sie wird
                        beim Schreiben aus dem Kapiteltext erzeugt (nichts erfunden). Zum Gegenlesen vorher im
                        Tab „Stand &amp; Export“ erstellen.
                      </p>
                    )}
                  </div>
                ) : (
                  <p className="text-xs text-text-muted">Kapitel 1 hat keinen Vorgänger – kein Anknüpfpunkt nötig.</p>
                )}
                <Button onClick={() => automatikStarten(false, false, true)}>
                  Kapitel {vorschau.zu_schreiben.join(", ")} schreiben
                </Button>
              </div>
            )}
          </div>
        )}

        {herunterfahrenGeplantBis != null && herunterfahrenRest > 0 && (
          <div className="mb-3 flex flex-wrap items-center gap-3 rounded-lg border border-amber-400/60 bg-amber-400/10 p-3">
            <p className="text-sm text-text">
              ⏻ Automatikmodus fertig – der PC fährt in <strong>{herunterfahrenRest} s</strong> herunter.
            </p>
            <Button variant="danger" onClick={herunterfahrenAbbrechen}>
              Herunterfahren abbrechen
            </Button>
          </div>
        )}
        {herunterfahrenFehler && <p className="mb-3 text-sm text-red-400">{herunterfahrenFehler}</p>}

        {!automatikStatus?.laeuft && (
          <div className="mb-3 space-y-1">
            <Label>Nach Fertigstellung (alle Kapitel und Prüfer durch)</Label>
            <label className="flex items-center gap-2 text-sm text-text">
              <input type="checkbox" checked={fertigSound} onChange={(e) => setFertigSound(e.target.checked)} />
              🔔 Signalton abspielen
            </label>
            {fertigSound && (
              <div className="ml-6 flex flex-wrap items-center gap-2">
                <div className="w-56">
                  <Select value={soundId} onChange={(e) => setSoundId(e.target.value)}>
                    {(["Allgemein", "Themen"] as const).map((gruppe) => (
                      <optgroup key={gruppe} label={gruppe}>
                        {SOUND_LISTE.filter((s) => s.gruppe === gruppe).map((s) => (
                          <option key={s.id} value={s.id}>
                            {s.name}
                          </option>
                        ))}
                      </optgroup>
                    ))}
                  </Select>
                </div>
                <Button
                  variant="secondary"
                  onClick={() => {
                    soundFreischalten();
                    fertigSoundAbspielen(soundId);
                  }}
                >
                  ▶ Vorhören
                </Button>
              </div>
            )}
            {automatikStatus?.herunterfahren_moeglich && (
              <label className="flex items-center gap-2 text-sm text-text">
                <input
                  type="checkbox"
                  checked={fertigHerunterfahren}
                  onChange={(e) => setFertigHerunterfahren(e.target.checked)}
                />
                ⏻ Danach PC herunterfahren (60 s Vorlauf, abbrechbar – gilt nur für den nächsten Start)
              </label>
            )}
          </div>
        )}

        {automatikStatus?.laeuft ? (
          <div className="space-y-3">
            {(automatikStatus.nach_fertig_sound || automatikStatus.nach_fertig_herunterfahren) && (
              <p className="text-xs text-text-muted">
                Nach Fertigstellung:{" "}
                {[
                  automatikStatus.nach_fertig_sound && "🔔 Signalton",
                  automatikStatus.nach_fertig_herunterfahren && "⏻ PC herunterfahren",
                ]
                  .filter(Boolean)
                  .join(" + ")}
              </p>
            )}
            <p className="text-sm text-text">
              Phase: <strong>{automatikStatus.phase}</strong>
              {automatikStatus.aktuelles_kapitel != null && (
                <>
                  {" "}
                  · Kapitel {automatikStatus.aktuelles_kapitel}
                  {automatikStatus.gesamt_kapitel != null && <>/{automatikStatus.gesamt_kapitel}</>}
                </>
              )}
              {automatikStatus.aktueller_durchlauf != null && <> · Durchlauf {automatikStatus.aktueller_durchlauf}</>}
            </p>
            <div className="max-h-40 overflow-auto rounded-lg bg-bg p-2 font-mono text-xs text-text-muted">
              {automatikStatus.log.length === 0 ? (
                <p>Startet...</p>
              ) : (
                automatikStatus.log.slice(-20).map((zeile, i) => <div key={i}>{zeile}</div>)
              )}
            </div>
            {automatikStatus.stop_angefordert && (
              <p className="text-xs text-text-muted">
                Stop angefordert - das laufende Kapitel wird noch fertig geschrieben, geprüft und gespeichert (nichts
                geht dabei verloren), erst danach hält der Lauf vor dem nächsten Kapitel an. Das kann je nach Kapitel
                noch einige Minuten dauern.
              </p>
            )}
            <Button variant="danger" onClick={automatikStoppen} disabled={automatikStatus.stop_angefordert}>
              {automatikStatus.stop_angefordert ? "Wird gestoppt..." : "Stoppen"}
            </Button>
          </div>
        ) : (
          <div className="space-y-3">
            {automatikStatus?.abgeschlossen && (automatikStatus.speicherkontrolle_gestoppt?.length ?? 0) > 0 && (
              <SpeicherkontrolleWiederhochBanner
                container={automatikStatus.speicherkontrolle_gestoppt}
                zielId={sshZielId || null}
              />
            )}
            {automatikStatus?.fortsetzbar && (
              <div className="flex flex-wrap items-center gap-3">
                <Button onClick={() => automatikStarten(true)}>Fortsetzen</Button>
                {automatikStatus.fehler_schritt && (
                  <p className="text-sm text-text-muted">
                    {automatikStatus.fehler_schritt.fehler_nummer ?? "Fehler"}: versuchter Schritt war: Kapitel{" "}
                    {automatikStatus.fehler_schritt.kapitel}, Phase {automatikStatus.fehler_schritt.phase}
                    {automatikStatus.fehler_schritt.durchlauf != null && (
                      <>, Durchlauf {automatikStatus.fehler_schritt.durchlauf}</>
                    )}
                  </p>
                )}
              </div>
            )}
            <div className="flex flex-wrap items-end gap-3">
              <div>
                <Label>Max. Durchläufe je Kapitel</Label>
                <Input
                  type="number"
                  min={1}
                  max={10}
                  value={automatikMaxDurchlaeufe}
                  onChange={(e) => setAutomatikMaxDurchlaeufe(Number(e.target.value))}
                  className="w-24"
                />
              </div>
              <Button variant={automatikStatus?.fortsetzbar ? "secondary" : "primary"} onClick={() => automatikStarten(false)}>
                Automatikmodus starten
              </Button>
              <Button variant="secondary" onClick={() => automatikStarten(false, true)}>
                🌙 Bestätige alles auf dem Weg
              </Button>
            </div>
            <p className="text-xs text-text-muted">
              "🌙 Bestätige alles auf dem Weg" überspringt den sonst alle paar Kapitel greifenden Zwischenstopp bei
              ungelösten Prüfer-Funden (siehe Hinweis unten) - für unbeaufsichtigte Läufe über Nacht. Übersprungene
              Funde sammeln sich trotzdem im Protokoll und lassen sich danach in Ruhe im Tab "Prüfen &amp; Anwenden"
              nachpflegen.
            </p>
          </div>
        )}

        {automatikFehler && <p className="mt-2 text-sm text-red-400">{automatikFehler}</p>}
        {automatikStatus?.fehler && (
          <p className="mt-2 text-sm text-red-400">Fehler im letzten Lauf: {automatikStatus.fehler}</p>
        )}

        </div>
      </CollapsibleCard>

        {!automatikStatus?.laeuft && automatikStatus != null && automatikStatus.protokoll.length > 0 && (() => {
          const reste = hatReste(automatikStatus.protokoll);
          const zusammenfassung = resteZusammenfassen(automatikStatus.protokoll);
          const uebersprungenGesamt = zusammenfassung.gesamt - zusammenfassung.angewendet;
          return (
            <>
              <CollapsibleCard
                title={`📋 Protokoll des letzten Laufs (${zusammenfassung.angewendet}/${zusammenfassung.gesamt} angewendet${
                  uebersprungenGesamt > 0 ? `, ${uebersprungenGesamt} übersprungen` : ""
                })`}
                defaultOffen={false}
              >
                <div className="space-y-2 p-4 text-xs text-text-muted">
                  {uebersprungenGesamt > 0 && (
                    <p>
                      {uebersprungenGesamt} von {zusammenfassung.gesamt} Korrekturvorschlägen übersprungen:{" "}
                      {Object.entries(zusammenfassung.uebersprungenNachGrund)
                        .map(([grund, anzahl]) => `${anzahl}× ${GRUND_LABEL[grund] ?? grund}`)
                        .join(", ")}
                      .
                    </p>
                  )}
                  {zusammenfassung.unbekannteWoerter > 0 && (
                    <p>{zusammenfassung.unbekannteWoerter} unbekannte(s) Wort/Wörter (Rechtschreibung, hunspell).</p>
                  )}
                  <ul className="max-h-64 space-y-1 overflow-auto">
                    {automatikStatus.protokoll.map((eintrag, i) => (
                      <li key={i}>
                        Kapitel {eintrag.kapitel}:{" "}
                        {eintrag.art === "angewendet"
                          ? "✅ angewendet"
                          : eintrag.art === "rechtschreibung"
                            ? `📝 ${eintrag.unbekannte_woerter?.length ?? 0} unbekannte(s) Wort/Wörter`
                            : `⏭️ übersprungen (${GRUND_LABEL[eintrag.grund ?? ""] ?? eintrag.grund})`}
                        {eintrag.fundstelle && <> – „{eintrag.fundstelle}“</>}
                      </li>
                    ))}
                  </ul>
                  <p>
                    Reste findest du wie gewohnt im Tab "Prüfen &amp; Anwenden"
                    {reste && !automatikStatus.resten_bestaetigt && (
                      <> - dort auch der Button "Prüfung abschließen".</>
                    )}
                  </p>
                  {reste && automatikStatus.resten_bestaetigt && (
                    <p className="text-accent-light">✅ Prüfung als abgeschlossen bestätigt.</p>
                  )}
                </div>
              </CollapsibleCard>
            </>
          );
        })()}

        {automatikVerlauf.length > 0 && (
          <CollapsibleCard title={`🕘 Lauf-Historie (${automatikVerlauf.length})`} defaultOffen={false}>
            <ul className="max-h-64 space-y-1 overflow-auto p-4 text-xs text-text-muted">
              {[...automatikVerlauf].reverse().map((eintrag, i) => (
                <li key={i}>
                  {eintrag.datum}: {eintrag.von.slice(11)}–{eintrag.bis.slice(11)} Uhr (
                  {formatDauer(eintrag.dauer_sekunden)}) ·{" "}
                  {eintrag.status === "abgeschlossen"
                    ? "✅ abgeschlossen"
                    : eintrag.status === "fehler"
                      ? "❌ Fehler"
                      : "⏹️ gestoppt"}
                  {eintrag.fortgesetzt && " (Fortsetzung)"}
                  {eintrag.fehler && <> – {eintrag.fehler}</>}
                </li>
              ))}
            </ul>
          </CollapsibleCard>
        )}
      </div>
      </div>
    </div>
  );
}
