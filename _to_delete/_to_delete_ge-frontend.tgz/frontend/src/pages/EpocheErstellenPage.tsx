import Editor from "@monaco-editor/react";
import { useEffect, useState } from "react";
import { api } from "../api/client";
import type { EpocheKurz } from "../api/types";
import { ConfirmDialog } from "../components/ConfirmDialog";
import {
  EpocheFormular,
  epocheFormularGueltig,
  LEERES_EPOCHE_FORMULAR,
  type EpocheFormularWerte,
} from "../components/EpocheFormular";
import { Button, Card, CardTitle, Input, Label } from "../components/ui";

const EPOCHE_DATEI_BESCHRIFTUNG: Record<string, string> = {
  "architekt.txt": "🗺️ Architekt",
  "autor.txt": "✍️ Autor",
  "pruefer_anachronismus.txt": "🔍 Anachronismus- & Stimmigkeits-Prüfer",
  "verbotsliste.md": "🚫 Verbotsliste",
  "einleitungssatz.txt": "📖 Einleitungssatz",
};

/** Editor fuer den Rohentwurf EINER zentralen Epoche (die vier Dateien aus
 * app/core/epoche.py:epoche_dateien_erzeugen plus das optionale Genre) -
 * anders als PersonasPage.tsx wirken Aenderungen hier NICHT nur auf ein
 * einzelnes Projekt, sondern auf die Bibliothek selbst, aus der zukuenftig
 * angelegte Projekte ihre Kopie ziehen (siehe app/api/epochen.py). */
// Fallback-Farbe fuer das native Colorpicker-Widget, solange die Epoche
// noch keine eigene Farbe hat - neutrales Grau statt Weiss/Schwarz, damit
// der Picker nicht wie ein bereits (falsch) gesetzter Wert aussieht.
const FARBE_FALLBACK = "#94a3b8";

function EpocheBearbeiten({
  ordner,
  anzeigename,
  genre,
  farbe,
  onEpochenGeaendert,
  onOrdnerGeaendert,
}: {
  ordner: string;
  anzeigename: string;
  genre: string | null;
  farbe: string | null;
  onEpochenGeaendert: () => void;
  // Nur aufgerufen, wenn epoche_umbenennen() auch den physischen Ordner
  // mitgezogen hat (siehe app/api/epochen.py) - der Aufrufer haelt den
  // aktuell bearbeiteten Ordnernamen im State (bearbeiteOrdner) und muss
  // ihn nachziehen, sonst klappt das Bearbeiten-Panel beim naechsten Klick
  // unerwartet zu, weil der alte Name nicht mehr existiert.
  onOrdnerGeaendert: (neuerOrdner: string) => void;
}) {
  const [dateinamen, setDateinamen] = useState<string[]>([]);
  const [ausgewaehlt, setAusgewaehlt] = useState<string | null>(null);
  const [inhalt, setInhalt] = useState("");
  const [wirdGeladen, setWirdGeladen] = useState(true);
  const [wirdGespeichert, setWirdGespeichert] = useState(false);
  const [gespeichertHinweis, setGespeichertHinweis] = useState<string | null>(null);

  const [nameEntwurf, setNameEntwurf] = useState(anzeigename);
  const [nameWirdGespeichert, setNameWirdGespeichert] = useState(false);
  const [nameFehler, setNameFehler] = useState<string | null>(null);

  const [genreEntwurf, setGenreEntwurf] = useState(genre ?? "");
  const [genreWirdGespeichert, setGenreWirdGespeichert] = useState(false);
  const [genreGespeichertHinweis, setGenreGespeichertHinweis] = useState<string | null>(null);

  const [farbeEntwurf, setFarbeEntwurf] = useState(farbe ?? "");
  const [farbeWirdGespeichert, setFarbeWirdGespeichert] = useState(false);
  const [farbeGespeichertHinweis, setFarbeGespeichertHinweis] = useState<string | null>(null);

  useEffect(() => {
    api.epocheDateienAuflisten(ordner).then((liste) => {
      setDateinamen(liste);
      if (liste.length > 0) setAusgewaehlt(liste[0]);
    });
  }, [ordner]);

  useEffect(() => {
    if (!ausgewaehlt) return;
    setWirdGeladen(true);
    setGespeichertHinweis(null);
    api.epocheDateiLesen(ordner, ausgewaehlt).then((text) => {
      setInhalt(text);
      setWirdGeladen(false);
    });
  }, [ordner, ausgewaehlt]);

  async function dateiSpeichern() {
    if (!ausgewaehlt) return;
    setWirdGespeichert(true);
    setGespeichertHinweis(null);
    try {
      await api.epocheDateiSchreiben(ordner, ausgewaehlt, inhalt);
      setGespeichertHinweis("Gespeichert.");
    } finally {
      setWirdGespeichert(false);
    }
  }

  async function nameSpeichern() {
    const neuerName = nameEntwurf.trim();
    if (!neuerName) return;
    setNameWirdGespeichert(true);
    setNameFehler(null);
    try {
      const antwort = await api.epocheUmbenennen(ordner, neuerName);
      onEpochenGeaendert();
      if (antwort.ordner !== ordner) onOrdnerGeaendert(antwort.ordner);
    } catch (e) {
      setNameFehler(e instanceof Error ? e.message : String(e));
    } finally {
      setNameWirdGespeichert(false);
    }
  }

  async function genreSpeichern() {
    setGenreWirdGespeichert(true);
    setGenreGespeichertHinweis(null);
    try {
      await api.epocheGenreSchreiben(ordner, genreEntwurf);
      setGenreGespeichertHinweis("Gespeichert.");
      onEpochenGeaendert();
    } finally {
      setGenreWirdGespeichert(false);
    }
  }

  async function farbeSpeichern(neueFarbe: string) {
    setFarbeEntwurf(neueFarbe);
    setFarbeWirdGespeichert(true);
    setFarbeGespeichertHinweis(null);
    try {
      await api.epocheFarbeSchreiben(ordner, neueFarbe);
      setFarbeGespeichertHinweis("Gespeichert.");
      onEpochenGeaendert();
    } finally {
      setFarbeWirdGespeichert(false);
    }
  }

  return (
    <div className="grid grid-cols-1 gap-4 border-t border-border bg-bg/40 p-4 lg:grid-cols-[1fr_2fr]">
      <div className="space-y-4">
        <div>
          <Label>Name</Label>
          <div className="flex gap-2">
            <Input
              value={nameEntwurf}
              onChange={(e) => setNameEntwurf(e.target.value)}
              placeholder="z.B. Viktorianisches England"
            />
            <Button variant="secondary" onClick={nameSpeichern} disabled={nameWirdGespeichert || !nameEntwurf.trim()}>
              {nameWirdGespeichert ? "..." : "OK"}
            </Button>
          </div>
          {nameFehler && <p className="mt-1 text-xs text-red-400">{nameFehler}</p>}
        </div>
        <div>
          <Label>Genre-Prägung</Label>
          <div className="flex gap-2">
            <Input
              value={genreEntwurf}
              onChange={(e) => setGenreEntwurf(e.target.value)}
              placeholder="z.B. Krimi, Dark Fantasy"
            />
            <Button variant="secondary" onClick={genreSpeichern} disabled={genreWirdGespeichert}>
              {genreWirdGespeichert ? "..." : "OK"}
            </Button>
          </div>
          {genreGespeichertHinweis && <p className="mt-1 text-xs text-accent-light">{genreGespeichertHinweis}</p>}
        </div>
        <div>
          <Label>Farbe (Projektliste)</Label>
          <div className="flex items-center gap-2">
            <input
              type="color"
              value={farbeEntwurf || FARBE_FALLBACK}
              onChange={(e) => farbeSpeichern(e.target.value)}
              disabled={farbeWirdGespeichert}
              className="h-9 w-14 cursor-pointer rounded-lg border border-border bg-bg p-1 disabled:cursor-not-allowed disabled:opacity-40"
            />
            {farbeEntwurf && (
              <button
                type="button"
                onClick={() => farbeSpeichern("")}
                disabled={farbeWirdGespeichert}
                className="text-xs text-text-muted hover:text-text disabled:opacity-40"
              >
                Zurücksetzen
              </button>
            )}
          </div>
          {farbeGespeichertHinweis && <p className="mt-1 text-xs text-accent-light">{farbeGespeichertHinweis}</p>}
        </div>
        <div>
          <Label>Dateien</Label>
          <ul className="space-y-1">
            {dateinamen.map((name) => (
              <li key={name}>
                <button
                  onClick={() => setAusgewaehlt(name)}
                  className={`w-full rounded-lg px-3 py-2 text-left text-sm transition-colors ${
                    ausgewaehlt === name
                      ? "bg-accent-soft text-accent-light"
                      : "text-text-muted hover:bg-surface-hover hover:text-text"
                  }`}
                >
                  {EPOCHE_DATEI_BESCHRIFTUNG[name] ?? name}
                </button>
              </li>
            ))}
          </ul>
        </div>
      </div>

      <div>
        <div className="mb-2 flex items-center justify-between">
          <span className="text-sm font-medium text-text">
            {ausgewaehlt ? (EPOCHE_DATEI_BESCHRIFTUNG[ausgewaehlt] ?? ausgewaehlt) : "Datei wählen"}
          </span>
          <div className="flex items-center gap-2">
            {gespeichertHinweis && <span className="text-xs text-accent-light">{gespeichertHinweis}</span>}
            <Button onClick={dateiSpeichern} disabled={wirdGespeichert || wirdGeladen || !ausgewaehlt}>
              {wirdGespeichert ? "Speichert..." : "Speichern"}
            </Button>
          </div>
        </div>
        <Editor
          height="clamp(320px, 55vh, 440px)"
          defaultLanguage="markdown"
          value={inhalt}
          onChange={(v) => setInhalt(v ?? "")}
          theme="vs-dark"
          options={{ wordWrap: "on", minimap: { enabled: false }, fontSize: 14 }}
        />
      </div>
    </div>
  );
}

interface EpocheErstellenPageProps {
  epochen: EpocheKurz[];
  onEpochenGeaendert: () => void;
}

/** Reines Frageformular (kein LLM-Aufruf) zum Anlegen einer neuen Epoche/
 * eines neuen Settings unter der zentralen Epochen-Bibliothek - portiert
 * aus pre-GUI/novelle.py's cmd_epoche_erstellen(). Das Ergebnis ist
 * bewusst ein ROHENTWURF: verbotsliste.md und pruefer_anachronismus.txt
 * brauchen danach noch echte Recherche (siehe Bedienungsanleitung
 * Abschnitt 10) - direkt hier ueber "Bearbeiten" bei der jeweiligen Epoche
 * (siehe EpocheBearbeiten oben), alternativ ueber ein neues Projekt mit
 * dieser Epoche und den Personas-/Verbotsliste-Editoren dort (wirkt dann
 * aber nur auf die Kopie dieses einen Projekts, nicht auf die Bibliothek).
 * `epochen` kommt von App.tsx (zusammen mit `onEpochenGeaendert`), damit
 * eine hier neu angelegte oder geloeschte Epoche sofort auch im "Neues
 * Projekt"-Dropdown von ProjektePage auftaucht, ohne Reload. */
export function EpocheErstellenPage({ epochen, onEpochenGeaendert }: EpocheErstellenPageProps) {
  const [formular, setFormular] = useState<EpocheFormularWerte>(LEERES_EPOCHE_FORMULAR);
  const [wirdAngelegt, setWirdAngelegt] = useState(false);
  const [fehler, setFehler] = useState<string | null>(null);
  const [ergebnis, setErgebnis] = useState<{ name: string; ordner: string; dateien: Record<string, string> } | null>(
    null,
  );

  const [loeschenAnfrage, setLoeschenAnfrage] = useState<EpocheKurz | null>(null);
  const [wirdGeloescht, setWirdGeloescht] = useState<string | null>(null);
  const [loeschenFehler, setLoeschenFehler] = useState<string | null>(null);
  const [bearbeiteOrdner, setBearbeiteOrdner] = useState<string | null>(null);

  async function epocheLoeschenBestaetigt() {
    if (!loeschenAnfrage) return;
    const name = loeschenAnfrage.name;
    setWirdGeloescht(name);
    setLoeschenFehler(null);
    try {
      await api.epocheLoeschen(name);
      setLoeschenAnfrage(null);
      if (bearbeiteOrdner === name) setBearbeiteOrdner(null);
      onEpochenGeaendert();
    } catch (e) {
      setLoeschenFehler(e instanceof Error ? e.message : String(e));
    } finally {
      setWirdGeloescht(null);
    }
  }

  function feld<K extends keyof EpocheFormularWerte>(name: K, wert: EpocheFormularWerte[K]) {
    setFormular((bisher) => ({ ...bisher, [name]: wert }));
  }

  const formularGueltig = epocheFormularGueltig(formular);

  async function anlegen() {
    setWirdAngelegt(true);
    setFehler(null);
    setErgebnis(null);
    try {
      const antwort = await fetch("/api/epochen", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formular),
      });
      if (!antwort.ok) {
        const body = await antwort.json().catch(() => ({}));
        throw new Error(body.detail ?? antwort.statusText);
      }
      setErgebnis(await antwort.json());
      setFormular(LEERES_EPOCHE_FORMULAR);
      onEpochenGeaendert();
    } catch (e) {
      setFehler(e instanceof Error ? e.message : String(e));
    } finally {
      setWirdAngelegt(false);
    }
  }

  if (ergebnis) {
    return (
      <div className="p-4 sm:p-6">
        <Card className="mx-auto max-w-2xl">
          <CardTitle>✅ Rohentwurf angelegt: {ergebnis.name}</CardTitle>
          <p className="mb-3 text-sm text-text-muted">
            Vier Dateien wurden unter <code className="text-text">epochen/{ergebnis.ordner}/</code> angelegt.
            Das ist ein <strong className="text-text">Rohentwurf</strong>, kein fertiges Setting - vor allem
            zwei Dateien sind noch mit "HIER ERGÄNZEN" markiert und brauchen echte Recherche (am besten mit
            Websuche in einem eigenen Gespräch, nicht dem lokalen Modell überlassen):
          </p>
          <ul className="mb-4 list-inside list-disc text-sm text-text-muted">
            <li>verbotsliste.md</li>
            <li>pruefer_anachronismus.txt</li>
          </ul>
          <p className="mb-4 text-sm text-text-muted">
            Am einfachsten verfeinerst du sie direkt hier: Klick unten in der Liste "Vorhandene Epochen" auf
            "Bearbeiten" bei <strong className="text-text">{ergebnis.name}</strong>.
          </p>
          <Button onClick={() => setErgebnis(null)}>Weitere Epoche anlegen</Button>
        </Card>
      </div>
    );
  }

  return (
    <div className="seite grid grid-cols-1 items-start gap-6 p-4 sm:p-6 lg:grid-cols-[minmax(0,1fr)_minmax(0,1fr)]">
      <Card className="flex flex-col lg:overflow-hidden">
        <CardTitle>📜 Vorhandene Epochen</CardTitle>
        {loeschenFehler && <p className="mb-3 text-sm text-red-400">{loeschenFehler}</p>}
        {epochen.length === 0 ? (
          <p className="text-sm text-text-muted">Noch keine Epoche angelegt.</p>
        ) : (
          <ul className="min-h-0 lg:max-h-none lg:flex-1 divide-y divide-border overflow-y-auto pr-1">
            {epochen.map((e) => (
              <li key={e.name}>
                <div className="flex items-center gap-3 px-1 py-2 text-sm">
                  <button
                    onClick={() => setLoeschenAnfrage(e)}
                    disabled={wirdGeloescht === e.name}
                    title={`Epoche "${e.name}" löschen`}
                    aria-label={`Epoche "${e.name}" löschen`}
                    className="shrink-0 text-sm leading-none text-red-400/60 transition-colors hover:text-red-400 disabled:opacity-40"
                  >
                    ✕
                  </button>
                  <div className="flex-1">
                    <div className="flex items-center gap-1.5">
                      {e.farbe && (
                        <span
                          aria-hidden="true"
                          className="h-2.5 w-2.5 shrink-0 rounded-sm"
                          style={{ backgroundColor: e.farbe }}
                        />
                      )}
                      <span className="font-medium text-text">{e.anzeigename}</span>
                    </div>
                    {e.genre && <div className="text-xs text-text-muted">{e.genre}</div>}
                  </div>
                  <button
                    onClick={() => setBearbeiteOrdner((bisher) => (bisher === e.name ? null : e.name))}
                    className={`shrink-0 rounded-lg border px-3 py-1.5 text-xs transition-colors ${
                      bearbeiteOrdner === e.name
                        ? "border-accent bg-accent-soft text-accent-light"
                        : "border-border text-text-muted hover:bg-surface-hover hover:text-text"
                    }`}
                  >
                    {bearbeiteOrdner === e.name ? "Schließen" : "✏️ Bearbeiten"}
                  </button>
                </div>
                {bearbeiteOrdner === e.name && (
                  <EpocheBearbeiten
                    key={e.name}
                    ordner={e.name}
                    anzeigename={e.anzeigename}
                    genre={e.genre ?? null}
                    farbe={e.farbe ?? null}
                    onEpochenGeaendert={onEpochenGeaendert}
                    onOrdnerGeaendert={setBearbeiteOrdner}
                  />
                )}
              </li>
            ))}
          </ul>
        )}
        <p className="mt-3 text-xs text-text-muted">
          Löscht nur die zentrale Epoche aus der Bibliothek - bereits damit angelegte Projekte behalten ihre
          eigenen Kopien der Personas/Verbotsliste und sind davon nicht betroffen.
        </p>
      </Card>

      <Card className="flex flex-col lg:overflow-hidden">
        <CardTitle>🏛️ Neue Epoche / neues Setting anlegen</CardTitle>
        <p className="mb-4 text-sm text-text-muted">
          Reines Frageformular, kein KI-Aufruf - kurze, direkte Antworten reichen. Das Ergebnis ist ein
          Rohentwurf, den du danach im jeweiligen Projekt weiter verfeinern kannst.
        </p>

        <div className="min-h-48 overflow-y-auto pr-1 lg:min-h-0 lg:flex-1">
          <EpocheFormular werte={formular} onChange={feld} />
        </div>

        <div className="mt-3 shrink-0 border-t border-border pt-3">
          {fehler && <p className="mb-2 text-sm text-red-400">{fehler}</p>}
          <Button onClick={anlegen} disabled={wirdAngelegt || !formularGueltig}>
            {wirdAngelegt ? "Legt an..." : "Epoche anlegen"}
          </Button>
        </div>
      </Card>

      {loeschenAnfrage && (
        <ConfirmDialog
          titel="Epoche löschen?"
          beschreibung={`"${loeschenAnfrage.name}" wird unwiderruflich aus der Epochen-Bibliothek entfernt. Bereits angelegte Projekte mit dieser Epoche sind nicht betroffen, da sie eigene Kopien der Dateien besitzen.`}
          bestaetigenText="Endgültig löschen"
          wirdAusgefuehrt={wirdGeloescht === loeschenAnfrage.name}
          onBestaetigen={epocheLoeschenBestaetigt}
          onAbbrechen={() => setLoeschenAnfrage(null)}
        />
      )}
    </div>
  );
}
