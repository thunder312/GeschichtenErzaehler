import Editor from "@monaco-editor/react";
import { useEffect, useRef, useState } from "react";
import { api } from "../api/client";
import type { FundusFigur, KiGeruestStatus, Ort, ProjektDetail } from "../api/types";
import { CollapsibleCard } from "../components/CollapsibleCard";
import { ConfirmDialog } from "../components/ConfirmDialog";
import { KiGeruestOverlay } from "../components/KiGeruestOverlay";
import { OrdnerUmbenennenDialog } from "../components/OrdnerUmbenennenDialog";
import { KapitelplanEditor } from "../components/KapitelplanEditor";
import { RahmenEditor } from "../components/RahmenEditor";
import { Badge, Button } from "../components/ui";
import { ordnernameAusTitel, titelAusGeruest } from "../utils/geruestVorlage";
import {
  geruestAusKapitelplanZusammenbauen,
  kapitelPflichtfelderPruefen,
  kapitelplanAusGeruestExtrahieren,
  leeresKapitel,
  type KapitelEintrag,
  type KapitelplanFehler,
} from "../utils/kapitelplan";
import {
  bearbeitetZuVor,
  rahmenAbschnitteVollstaendig,
  vorZuBearbeitet,
  type VorAbschnittBearbeitet,
} from "../utils/rahmen";

// Anzeige-Mapping der intern aus dem Gerüst erkannten Content-Stufe (siehe
// backend/app/core/rollen.py: STUFE_DIREKTIVEN) auf die aus Filmen bekannten
// FSK-Alterskennzeichen - "voll" klang vorher wie "Jugendschutz voll aktiv",
// war aber genau das Gegenteil (voll explizit, keine Einschraenkung).
const JUGENDSCHUTZ_ANZEIGE: Record<string, { label: string; tone: "green" | "amber" }> = {
  jugendfrei: { label: "FSK 0 · jugendfrei", tone: "green" },
  angedeutet: { label: "FSK 12 · angedeutet", tone: "green" },
  voll: { label: "FSK 18 · voll explizit", tone: "amber" },
};

/** Kopfzeile fuer einen der drei "Haupt-Container" INNERHALB des äußeren
 * "🗺️ geruest.md"-CollapsibleCard - bewusst kein verschachteltes
 * CollapsibleCard (das wuerde eine zweite Card-Umrandung ineinander
 * schachteln), sondern derselbe Titel+Toggle-Aufbau, nur ohne eigene
 * Card-Border. */
function AbschnittKopf({ titel, offen, onToggle }: { titel: string; offen: boolean; onToggle: () => void }) {
  return (
    <div onClick={onToggle} className="flex cursor-pointer items-center justify-between gap-3 px-4 pt-4">
      <h3 className="text-xs font-semibold uppercase tracking-wide text-text-muted">{titel}</h3>
      <span className="text-xs text-accent-light">{offen ? "Einklappen" : "Ausklappen"}</span>
    </div>
  );
}

interface GeruestPageProps {
  ordner: string;
  projekt: ProjektDetail | null;
  onGeaendert: () => void;
  onOrdnerUmbenannt: (neuerOrdner: string) => void;
  onInterviewStarten: () => void;
  /** Nach "Neu schreiben als Kopie" - wechselt in App.tsx zum frisch
   * angelegten Duplikat (Ordnername + "_v2") und oeffnet dessen Gerüst-Tab,
   * exakt wie der gleichnamige Button in der Projektliste. */
  onNeuSchreibenGestartet: (ordner: string) => void;
  /** true, solange der Tab "Architekt / Gerüst" sichtbar ist - der Wechsel
   * auf true beim erneuten Betreten klappt die Kapitel-Karten wieder ein. */
  aktiv: boolean;
  /** Fuer den KI-Gerüst-Entwurf (siehe KiGeruestOverlay) - kommt aus App.tsx,
   * wird an den Hintergrund-Task durchgereicht. */
  sshZielId: string;
  /** true, wenn der Nutzer beim Projekt-Anlegen "✨ KI entwirft das Gerüst"
   * gewaehlt hat (ProjektePage) - dann oeffnet sich das Overlay direkt beim
   * ersten Betreten. Muster wie interviewErzwungen in App.tsx. */
  kiEntwurfAuto: boolean;
  onKiEntwurfAutoVerbraucht: () => void;
}

/** Rohtext-Ansicht von geruest.md, fuer die manuelle Nachjustierung NACH dem
 * Architekten-Interview (siehe ArchitektInterviewPage - das ist der
 * eigentliche Weg, ein Gerüst zu erzeugen). Die Feldererkennung (Jahr,
 * Jugendschutz-Stufe, Autor-Modell, Kapitelplan, ...) laeuft serverseitig
 * exakt wie im CLI (siehe backend/app/core/geruest.py) und wird hier zur
 * Kontrolle angezeigt. Verbotsliste (fuer die Anachronismus-Pruefung)
 * liegt gleich daneben, da beide Dateien zusammen das Setting definieren. */
export function GeruestPage({ ordner, projekt, onGeaendert, onOrdnerUmbenannt, onInterviewStarten, onNeuSchreibenGestartet, aktiv, sshZielId, kiEntwurfAuto, onKiEntwurfAutoVerbraucht }: GeruestPageProps) {
  // Kapitelplan strukturiert (KapitelplanEditor), Rest des Gerüsts bleibt
  // Freitext in zwei Editoren links/rechts davon (siehe utils/kapitelplan.ts
  // fuer die Begruendung, warum nur der Kapitelplan formalisiert wird).
  // Praeambel ("# STORY-GERUEST") + strukturierte "## "-Abschnitte des Teils
  // VOR "## Kapitelplan" (Rahmen, Titel, Unerhörte Begebenheit, Figuren,
  // Konflikt, Nebenstrang, ...) - siehe utils/rahmen.ts und RahmenEditor.tsx.
  // rahmenAbschnitte===null bedeutet: im Text wurde ueberhaupt keine
  // "## "-Ueberschrift gefunden (z.B. ein von Hand komplett geleertes oder
  // sehr altes Gerüst) - dann bleibt rahmenRohFallback die einzige
  // Wahrheitsquelle und wird im rohen Markdown-Editor angezeigt, analog zur
  // "warnung" bei einem unparsbaren Kapitelplan weiter unten.
  const [rahmenPraeambel, setRahmenPraeambel] = useState("");
  const [rahmenAbschnitte, setRahmenAbschnitte] = useState<VorAbschnittBearbeitet[] | null>(null);
  const [rahmenRohFallback, setRahmenRohFallback] = useState("");
  const [kapitel, setKapitel] = useState<KapitelEintrag[]>([]);
  const [nach, setNach] = useState("");
  const [kapitelplanWarnung, setKapitelplanWarnung] = useState<string | null>(null);
  const [kapitelFehler, setKapitelFehler] = useState<KapitelplanFehler[]>([]);
  const [wirdGespeichert, setWirdGespeichert] = useState(false);
  const [gespeichertHinweis, setGespeichertHinweis] = useState<string | null>(null);
  const [geruestFehler, setGeruestFehler] = useState<string | null>(null);

  // "Zurücksetzen" (in-place, nur Gerüst behalten) und "Neu schreiben als
  // Kopie" (Duplikat _v2, wie in der Projektliste) - beide im Kopfbereich
  // des geruest.md-Containers. Der Warn-Dialog gilt nur fuers Zuruecksetzen,
  // da das die bestehende Instanz unumkehrbar leert.
  const [zuruecksetzenOffen, setZuruecksetzenOffen] = useState(false);
  const [wirdZurueckgesetzt, setWirdZurueckgesetzt] = useState(false);
  const [wirdKopiert, setWirdKopiert] = useState(false);
  const [aktionsFehler, setAktionsFehler] = useState<string | null>(null);

  // Expliziter "Ordner umbenennen"-Dialog - bewusst getrennt vom
  // Gerüst-Speichern (siehe app/api/projects.py:projekt_ordner_umbenennen).
  const [umbenennenOffen, setUmbenennenOffen] = useState(false);
  const [wirdUmbenannt, setWirdUmbenannt] = useState(false);
  const [umbenennenFehler, setUmbenennenFehler] = useState<string | null>(null);
  const aktuellerOrdnerName = ordner.split("/").pop() ?? ordner;

  const [verbotslisteInhalt, setVerbotslisteInhalt] = useState(projekt?.verbotsliste ?? "");
  const [verbotslisteWirdGespeichert, setVerbotslisteWirdGespeichert] = useState(false);
  const [verbotslisteHinweis, setVerbotslisteHinweis] = useState<string | null>(null);

  const [stilprobenInhalt, setStilprobenInhalt] = useState(projekt?.stilproben ?? "");
  const [stilprobenWirdGespeichert, setStilprobenWirdGespeichert] = useState(false);
  const [stilprobenHinweis, setStilprobenHinweis] = useState<string | null>(null);

  const [architektenGespraech, setArchitektenGespraech] = useState<string | null>(null);

  // KI-Gerüst-Entwurf (KiGeruestOverlay). `kiOverlay` steuert Sichtbarkeit +
  // Startphase: "eingabe" = Formular, "laeuft" = direkt Fortschritt (ein Lauf
  // war beim Betreten schon aktiv). `kiHinweis` ist das schließbare Banner
  // nach einem fertigen Entwurf ("bitte jedes Kapitel prüfen").
  const [kiOverlay, setKiOverlay] = useState<null | "eingabe" | "laeuft">(null);
  const [kiHinweis, setKiHinweis] = useState(false);
  // Serverseitiger Stand des KI-Gerüst-Entwurfs für dieses Projekt - wird
  // unabhängig vom Overlay gepollt, damit ein im Hintergrund laufender
  // Entwurf im Editor sichtbar bleibt (Banner) und sein Abschluss/Fehler
  // auch dann erkannt wird, wenn das Overlay geschlossen ist.
  const [kiStatus, setKiStatus] = useState<KiGeruestStatus | null>(null);
  // Bump = "gerade einen Entwurf gestartet" -> Polling (neu) anwerfen.
  const [kiLaufToken, setKiLaufToken] = useState(0);
  const kiPrevLaeuftRef = useRef(false);
  const kiFertigBehandeltRef = useRef(false);
  const onGeaendertRef = useRef(onGeaendert);
  onGeaendertRef.current = onGeaendert;
  const onOrdnerUmbenanntRef = useRef(onOrdnerUmbenannt);
  onOrdnerUmbenanntRef.current = onOrdnerUmbenannt;

  /** Ein KI-Gerüst-Entwurf ist fertig (von einmalPruefen unten ODER vom
   * KiGeruestOverlay-Polling erkannt, je nachdem was zuerst dran ist - siehe
   * kiPrevLaeuftRef/kiFertigBehandeltRef-Dedup). Benennt den Ordner einmalig
   * nach dem von der KI gewählten Titel um (sonst bliebe er bis zum nächsten
   * manuellen "Speichern" beim Platzhalternamen, siehe
   * backend/app/api/geruest_ki.py-Moduldocstring) und lädt das Gerüst neu.
   * `ordnerAktuell` kommt als Parameter rein statt aus der Prop `ordner` zu
   * lesen - nach einer vorherigen Umbenennung in DERSELBEN Session wäre die
   * Prop sonst noch der alte, inzwischen ungültige Pfad. */
  async function kiEntwurfAbgeschlossen(ordnerAktuell: string) {
    kiPrevLaeuftRef.current = false;
    kiFertigBehandeltRef.current = true;
    setKiOverlay(null);
    setKiHinweis(true);
    try {
      const { neuer_ordner } = await api.kiGeruestOrdnerAnpassen(ordnerAktuell);
      if (neuer_ordner) onOrdnerUmbenanntRef.current(neuer_ordner);
    } catch {
      // Best effort - der Nutzer kann die Umbenennung jederzeit ueber den
      // naechsten "Speichern"-Klick nachholen.
    }
    onGeaendertRef.current();
  }

  // Status des KI-Gerüst-Entwurfs pollen: einmal beim Betreten des Projekts
  // bzw. nach dem Start eines Entwurfs (kiLaufToken), danach im 8-s-Takt,
  // solange laeuft=true. Beim Übergang laeuft -> fertig wird das Gerüst neu
  // geladen und das Prüf-Banner gezeigt; bei laeuft -> fehler bleibt der
  // Fehler im Banner stehen (siehe Render). Bewusst 8 s (nicht 3-4 s wie
  // Automatik/Schreiben) - häufiges Pollen während eines laufenden
  // Ollama-Aufrufs über den SSH-Tunnel bremst diesen aus (siehe
  // AnalysatorPage / KiGeruestOverlay).
  useEffect(() => {
    let gestoppt = false;
    let intervall: ReturnType<typeof setInterval> | undefined;
    kiPrevLaeuftRef.current = false;
    kiFertigBehandeltRef.current = false;
    setKiStatus(null);

    const einmalPruefen = async (): Promise<boolean> => {
      try {
        const s = await api.kiGeruestStatus(ordner);
        if (gestoppt) return false;
        setKiStatus(s);
        if (s.laeuft) {
          kiPrevLaeuftRef.current = true;
          kiFertigBehandeltRef.current = false;
        } else if (kiPrevLaeuftRef.current && !kiFertigBehandeltRef.current) {
          if (s.abgeschlossen && !s.fehler) {
            kiEntwurfAbgeschlossen(ordner);
          } else {
            kiPrevLaeuftRef.current = false;
            kiFertigBehandeltRef.current = true;
          }
        }
        return s.laeuft;
      } catch {
        return false;
      }
    };

    einmalPruefen().then((laeuft) => {
      if (gestoppt || !laeuft) return;
      intervall = setInterval(async () => {
        const nochLaeuft = await einmalPruefen();
        if (!nochLaeuft && intervall) {
          clearInterval(intervall);
          intervall = undefined;
        }
      }, 8000);
    });

    return () => {
      gestoppt = true;
      if (intervall) clearInterval(intervall);
    };
  }, [ordner, kiLaufToken]);

  // "✨ KI entwirft das Gerüst" beim Anlegen gewählt (ProjektePage -> App.tsx):
  // Formular direkt öffnen und das Flag verbrauchen.
  useEffect(() => {
    if (!kiEntwurfAuto) return;
    setKiOverlay("eingabe");
    onKiEntwurfAutoVerbraucht();
  }, [kiEntwurfAuto, onKiEntwurfAutoVerbraucht]);

  // Fuer den Fundus-Abgleich im Figuren-Abschnitt (siehe RahmenEditor.tsx:
  // FigurenBlock) - einmal geladen, nicht projektabhaengig (der Fundus ist
  // nutzerweit, nicht projektweit). Schlaegt der Ladevorgang fehl, bleibt
  // die Liste einfach leer statt die Seite zu stoeren - der Abgleich ist ein
  // Zusatzkomfort, keine Kernfunktion dieser Seite.
  const [fundusFiguren, setFundusFiguren] = useState<FundusFigur[]>([]);
  useEffect(() => {
    api.fundusFigurenLesen()
      .then((antwort) => setFundusFiguren(antwort.figuren))
      .catch(() => {});
  }, []);

  // Fuer den Fundus-gespeisten Vorschlag im Feld "Ort" des Kapitelplans
  // (siehe OrtAuswahl.tsx) - gleiches Muster wie fundusFiguren oben.
  const [orte, setOrte] = useState<Ort[]>([]);
  useEffect(() => {
    api.orteListeLesen()
      .then((antwort) => setOrte(antwort.orte))
      .catch(() => {});
  }, []);

  // Einklappzustand der drei "Haupt-Container" innerhalb des geruest.md-
  // Editors (siehe ToDo.md: mehr Platz fuer den Block, an dem gerade
  // gearbeitet wird) - unabhaengig vom aeusseren "🗺️ geruest.md"-
  // CollapsibleCard und unabhaengig voneinander. Kapitelplan/Ausgangslage
  // starten offen; der "Rahmen, Titel, Figuren, ..."-Container startet
  // eingeklappt, sobald er vollstaendig ausgefuellt ist (siehe Lade-Effekt
  // und aktiv-Effekt unten) - das schafft Platz beim spaeteren Erweitern um
  // Kapitel.
  const [rahmenOffen, setRahmenOffen] = useState(true);
  const [kapitelplanOffen, setKapitelplanOffen] = useState(true);

  // "Rahmen, Titel, Figuren, ..."-Container beim (erneuten) Betreten des Tabs
  // wieder passend setzen: vollstaendig ausgefuellt -> eingeklappt, sonst
  // offen zum Weiterausfuellen. Waehrend der Nutzer auf der Seite ist, bleibt
  // sein manuelles Auf-/Zuklappen unangetastet.
  useEffect(() => {
    if (!aktiv) return;
    setRahmenOffen(rahmenAbschnitte === null || !rahmenAbschnitteVollstaendig(rahmenAbschnitte));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [aktiv]);

  useEffect(() => {
    const geteilt = kapitelplanAusGeruestExtrahieren(projekt?.geruest ?? "");
    const { praeambel, abschnitte } = vorZuBearbeitet(geteilt.vor);
    setRahmenPraeambel(praeambel);
    setRahmenAbschnitte(abschnitte);
    setRahmenRohFallback(abschnitte === null ? geteilt.vor : "");
    // Frisch geladenes, vollstaendig ausgefuelltes Gerüst: den Rahmen-Block
    // gleich eingeklappt zeigen (siehe Kommentar bei rahmenOffen oben).
    setRahmenOffen(abschnitte === null || !rahmenAbschnitteVollstaendig(abschnitte));
    // Ein Gerüst, das WIRKLICH noch keinen Kapitelplan hat (kein "kann nicht
    // geparst werden"-Fall, siehe warnung-Kommentar in kapitelplan.ts), zeigt
    // sofort ein erstes leeres Kapitel zum Ausfuellen statt der bisherigen
    // "Noch kein Kapitelplan"-Leermeldung - erspart den Klick auf "+ Kapitel"
    // bei jedem neu angelegten Projekt (z.B. frisch ueber "Gerüst selbst
    // schreiben" angelegt, siehe ProjektePage.tsx:anlegen). Rein lokaler
    // Editor-Zustand, wird erst beim Speichern validiert/persistiert - siehe
    // geruestVorlage.ts, warum das Startkapitel nicht schon im initial
    // gespeicherten Skelett steckt.
    setKapitel(geteilt.kapitel.length === 0 && !geteilt.warnung ? [leeresKapitel()] : geteilt.kapitel);
    setNach(geteilt.nach);
    setKapitelplanWarnung(geteilt.warnung);
    setKapitelFehler([]);
    setVerbotslisteInhalt(projekt?.verbotsliste ?? "");
    setStilprobenInhalt(projekt?.stilproben ?? "");
    setArchitektenGespraech(null);
    api
      .architektenGespraech(ordner)
      .then(setArchitektenGespraech)
      .catch(() => setArchitektenGespraech(null));
  }, [projekt?.geruest, projekt?.verbotsliste, projekt?.stilproben, ordner]);

  async function speichern() {
    setGespeichertHinweis(null);
    setGeruestFehler(null);

    // Pflichtfeld-Pruefung ZUERST, komplett ohne Server-Roundtrip - der
    // eigentliche Punkt von Schritt 2 (siehe utils/kapitelplan.ts). Die
    // serverseitige Pruefung (kapitelplan_pruefen()) bleibt trotzdem als
    // zweite Verteidigungslinie bestehen, siehe geruest_schreiben().
    const pflichtfeldFehler = kapitelPflichtfelderPruefen(kapitel);
    setKapitelFehler(pflichtfeldFehler);
    if (pflichtfeldFehler.length > 0) {
      setGeruestFehler(
        `Kapitelplan unvollständig:\n${pflichtfeldFehler.map((f) => f.meldung).join("\n")}`,
      );
      return;
    }

    setWirdGespeichert(true);
    try {
      const vorText = rahmenAbschnitte !== null ? bearbeitetZuVor(rahmenPraeambel, rahmenAbschnitte) : rahmenRohFallback;
      const inhalt = geruestAusKapitelplanZusammenbauen(vorText, kapitel, nach);
      const antwort = await api.geruestSchreiben(ordner, inhalt);
      const zusatz = antwort.stand_00_aktualisiert ? " Ausgangslage vor Kapitel eins (stand_00.md) synchronisiert." : "";
      if (antwort.neuer_ordner) {
        onOrdnerUmbenannt(antwort.neuer_ordner);
        setGespeichertHinweis(`Gespeichert - Ordner umbenannt in "${antwort.neuer_ordner}".${zusatz}`);
      } else {
        onGeaendert();
        // Titel im Gerüst und Ordnername laufen auseinander (Umbenennen beim
        // Speichern klappt nur, solange noch kein Kapitel existiert) - das
        // Kapitel-1-Titelblatt nutzt den Gerüst-Titel, der Ordner den alten.
        const titel = titelAusGeruest(inhalt);
        const ordnerOhneZaehler = aktuellerOrdnerName.replace(/-\d+$/, "");
        const abweichung =
          titel && ordnernameAusTitel(titel) !== aktuellerOrdnerName && ordnernameAusTitel(titel) !== ordnerOhneZaehler
            ? ` Hinweis: Der Titel "${titel}" passt nicht zum Ordnernamen "${aktuellerOrdnerName}" - bei Bedarf "Ordner umbenennen".`
            : "";
        setGespeichertHinweis(`Gespeichert.${zusatz}${abweichung}`);
      }
    } catch (e) {
      // Ueblicherweise die 400-Antwort von geruest_schreiben() bei einem
      // unvollstaendigen Kapitelplan (fehlende Zielwortzahl, doppelte
      // Kapitelnummer, siehe app/core/geruest.py:kapitelplan_pruefen) - der
      // alte Speicherstand bleibt dabei serverseitig unangetastet.
      setGeruestFehler(e instanceof Error ? e.message : String(e));
    } finally {
      setWirdGespeichert(false);
    }
  }

  async function verbotslisteSpeichern() {
    setVerbotslisteWirdGespeichert(true);
    setVerbotslisteHinweis(null);
    try {
      await api.verbotslisteSchreiben(ordner, verbotslisteInhalt);
      onGeaendert();
      setVerbotslisteHinweis("Gespeichert.");
    } finally {
      setVerbotslisteWirdGespeichert(false);
    }
  }

  async function stilprobenSpeichern() {
    setStilprobenWirdGespeichert(true);
    setStilprobenHinweis(null);
    try {
      await api.stilprobenSchreiben(ordner, stilprobenInhalt);
      onGeaendert();
      setStilprobenHinweis("Gespeichert.");
    } finally {
      setStilprobenWirdGespeichert(false);
    }
  }

  async function zuruecksetzenBestaetigt() {
    setWirdZurueckgesetzt(true);
    setAktionsFehler(null);
    try {
      await api.projektZuruecksetzen(ordner);
      setZuruecksetzenOffen(false);
      onGeaendert();
    } catch (e) {
      setAktionsFehler(e instanceof Error ? e.message : String(e));
    } finally {
      setWirdZurueckgesetzt(false);
    }
  }

  async function ordnerUmbenennen(neuerName: string) {
    setWirdUmbenannt(true);
    setUmbenennenFehler(null);
    try {
      const { neuer_ordner } = await api.projektOrdnerUmbenennen(ordner, neuerName);
      setUmbenennenOffen(false);
      onOrdnerUmbenannt(neuer_ordner);
    } catch (e) {
      setUmbenennenFehler(e instanceof Error ? e.message : String(e));
    } finally {
      setWirdUmbenannt(false);
    }
  }

  async function alsKopieNeuSchreiben() {
    setWirdKopiert(true);
    setAktionsFehler(null);
    try {
      // Reine Dateikopie (siehe app/api/projects.py:projekt_neu_schreiben),
      // identisch zum Button in der Projektliste - Automatikmodus wird NICHT
      // gestartet, der Nutzer landet im Gerüst-Tab des Duplikats.
      const kopie = await api.projektNeuSchreiben(ordner);
      onNeuSchreibenGestartet(kopie.ordner);
    } catch (e) {
      setAktionsFehler(e instanceof Error ? e.message : String(e));
    } finally {
      setWirdKopiert(false);
    }
  }

  return (
    <>
    <div className="seite grid grid-cols-1 items-start gap-6 p-4 sm:p-6 lg:grid-cols-[2fr_1fr]">
      <CollapsibleCard
        title="🗺️ geruest.md"
        aktionen={
          <>
            {gespeichertHinweis && <span className="text-xs text-accent-light">{gespeichertHinweis}</span>}
            {aktionsFehler && !zuruecksetzenOffen && (
              <span className="text-xs text-red-400">{aktionsFehler}</span>
            )}
            <Button
              variant="secondary"
              onClick={() => {
                setUmbenennenFehler(null);
                setUmbenennenOffen(true);
              }}
              disabled={wirdZurueckgesetzt || wirdKopiert}
              title="Den Projektordner umbenennen (ändert die Anzeige im Projekte-Tab, nicht den Titel im Gerüst)"
            >
              Ordner umbenennen
            </Button>
            <Button
              variant="secondary"
              onClick={() => {
                setAktionsFehler(null);
                setZuruecksetzenOffen(true);
              }}
              disabled={wirdZurueckgesetzt || wirdKopiert}
              title="Alle bisher geschriebenen Kapitel, Prüfungen und Sicherungen dieser Geschichte löschen - nur das Gerüst bleibt"
            >
              Zurücksetzen
            </Button>
            <Button
              variant="secondary"
              onClick={alsKopieNeuSchreiben}
              disabled={wirdKopiert || wirdZurueckgesetzt}
              title="Diese Geschichte als Kopie neu anlegen (Ordnername + _v2) - nur das Gerüst bleibt erhalten, das Original bleibt unangetastet"
            >
              {wirdKopiert ? "Kopiert..." : "Neu schreiben als Kopie"}
            </Button>
            <Button variant="secondary" onClick={onInterviewStarten}>
              Interview neu führen
            </Button>
            <Button
              variant="secondary"
              onClick={() => setKiOverlay("eingabe")}
              title="Die KI entwirft aus ein paar Randbedingungen einen kompletten Kapitelplan-Erstentwurf (überschreibt beim Speichern das aktuelle Gerüst)"
            >
              ✨ KI-Entwurf
            </Button>
            <Button onClick={speichern} disabled={wirdGespeichert}>
              {wirdGespeichert ? "Speichert..." : "Speichern"}
            </Button>
          </>
        }
      >
        {geruestFehler && (
          <p className="whitespace-pre-line border-b border-border bg-red-400/10 px-4 py-3 text-sm text-red-400">
            {geruestFehler}
          </p>
        )}

        {kiStatus?.laeuft && (
          <div className="flex items-center justify-between gap-3 border-b border-border bg-accent-soft px-4 py-3 text-sm text-accent-light">
            <span className="animate-pulse">
              ✨ Die KI entwirft gerade den Kapitelplan im Hintergrund
              {kiStatus.log.length > 0 ? ` – ${kiStatus.log[kiStatus.log.length - 1]}` : "…"}
            </span>
            <button
              type="button"
              onClick={() => setKiOverlay("laeuft")}
              className="shrink-0 rounded-full border border-accent-light/40 px-3 py-1 text-xs hover:bg-accent-light/10"
            >
              Fortschritt anzeigen
            </button>
          </div>
        )}

        {kiStatus && !kiStatus.laeuft && kiStatus.fehler && !kiHinweis && (
          <div className="flex items-start justify-between gap-3 border-b border-border bg-red-400/10 px-4 py-3 text-sm text-red-400">
            <span>✨ Der KI-Gerüst-Entwurf ist fehlgeschlagen: {kiStatus.fehler}</span>
            <span className="flex shrink-0 gap-3">
              <button type="button" onClick={() => setKiOverlay("eingabe")} className="hover:underline">
                Erneut versuchen
              </button>
              <button type="button" onClick={() => setKiStatus(null)} className="hover:text-red-300">
                ✕
              </button>
            </span>
          </div>
        )}

        {kiHinweis && (
          <div className="flex items-start justify-between gap-3 border-b border-border bg-amber-400/10 px-4 py-3 text-sm text-amber-300">
            <span>
              ✨ Dieses Gerüst wurde von der KI entworfen - bitte jedes Kapitel gegenlesen, Figuren/Orte
              prüfen und dann <strong>Speichern</strong>.
            </span>
            <button type="button" onClick={() => setKiHinweis(false)} className="shrink-0 hover:text-amber-200">
              ✕
            </button>
          </div>
        )}

        <div className="border-b border-border">
          <AbschnittKopf
            titel="Rahmen, Titel, Figuren, Konflikt, Nebenstrang"
            offen={rahmenOffen}
            onToggle={() => setRahmenOffen((o) => !o)}
          />
          {rahmenOffen &&
            (rahmenAbschnitte !== null ? (
              <RahmenEditor
                abschnitte={rahmenAbschnitte}
                onChange={setRahmenAbschnitte}
                fundusFiguren={fundusFiguren}
                epoche={projekt?.epoche}
                aktiv={aktiv}
              />
            ) : (
              <div className="p-4 pt-2">
                <p className="mb-2 rounded-lg border border-amber-400/30 bg-amber-400/10 px-3 py-2 text-xs text-amber-300">
                  ⚠️ Dieser Abschnitt konnte nicht in einzelne Felder zerlegt werden (keine erkennbare
                  "## "-Struktur) - er steht unverändert als Rohtext zur Bearbeitung.
                </p>
                <Editor
                  height="clamp(200px, 32vh, 360px)"
                  defaultLanguage="markdown"
                  value={rahmenRohFallback}
                  onChange={(v) => setRahmenRohFallback(v ?? "")}
                  theme="vs-dark"
                  options={{ wordWrap: "on", minimap: { enabled: false }, fontSize: 14 }}
                />
              </div>
            ))}
        </div>

        <div>
          <AbschnittKopf titel="Kapitelplan" offen={kapitelplanOffen} onToggle={() => setKapitelplanOffen((o) => !o)} />
          {kapitelplanOffen && (
            <>
              {kapitelplanWarnung && (
                <p className="mx-4 mt-2 rounded-lg border border-amber-400/30 bg-amber-400/10 px-3 py-2 text-xs text-amber-300">
                  ⚠️ {kapitelplanWarnung}
                </p>
              )}
              <KapitelplanEditor
                kapitel={kapitel}
                onChange={(neu) => {
                  // Jede Aenderung (auch Verschieben/Loeschen) macht die zuletzt
                  // berechneten Pflichtfeld-Fehler potenziell falsch - Index N
                  // zeigt nach einer Verschiebung auf ein ANDERES Kapitel als
                  // beim letzten Speicherversuch. Erst der naechste Speichern-
                  // Klick berechnet sie neu; bis dahin lieber keine (evtl.
                  // falsch zugeordnete) rote Markierung stehen lassen.
                  setKapitel(neu);
                  setKapitelFehler([]);
                }}
                fehler={kapitelFehler}
                fundusFiguren={fundusFiguren}
                orte={orte}
                epoche={projekt?.epoche}
                aktiv={aktiv}
              />
            </>
          )}
        </div>
      </CollapsibleCard>

      <div className="space-y-6">
        <CollapsibleCard title="🌅 Ausgangslage vor Kapitel eins" defaultOffen={false}>
          <Editor
            height="clamp(200px, 32vh, 360px)"
            defaultLanguage="markdown"
            value={nach}
            onChange={(v) => setNach(v ?? "")}
            theme="vs-dark"
            options={{ wordWrap: "on", minimap: { enabled: false }, fontSize: 13 }}
          />
        </CollapsibleCard>

        <CollapsibleCard title="🧩 Erkannte Felder" defaultOffen={false}>
        <div className="p-4">
          <dl className="space-y-2.5 text-sm">
            <div className="flex items-center justify-between">
              <dt className="text-text-muted">Jahr</dt>
              <dd>{projekt?.jahr ?? "–"}</dd>
            </div>
            <div className="flex items-center justify-between">
              <dt className="text-text-muted">Content-Stufe</dt>
              <dd>
                {projekt?.jugendschutz_stufe && JUGENDSCHUTZ_ANZEIGE[projekt.jugendschutz_stufe] ? (
                  <Badge tone={JUGENDSCHUTZ_ANZEIGE[projekt.jugendschutz_stufe].tone}>
                    {JUGENDSCHUTZ_ANZEIGE[projekt.jugendschutz_stufe].label}
                  </Badge>
                ) : (
                  <Badge>–</Badge>
                )}
              </dd>
            </div>
            <div className="flex items-center justify-between">
              <dt className="text-text-muted">Autor-Modell</dt>
              <dd>{projekt?.autor_modell ?? "–"}</dd>
            </div>
            <div className="flex items-center justify-between">
              <dt className="text-text-muted">Automatische Fortsetzung</dt>
              <dd>
                <Badge tone={projekt?.automatische_fortsetzung ? "amber" : "green"}>
                  {projekt?.automatische_fortsetzung ? "Ein" : "Aus"}
                </Badge>
              </dd>
            </div>
            <div className="flex items-center justify-between">
              <dt className="text-text-muted">Letztes geplantes Kapitel</dt>
              <dd>{projekt?.letztes_geplantes_kapitel ?? "–"}</dd>
            </div>
          </dl>

          {projekt && Object.keys(projekt.kapitelplan).length > 0 && (
            <>
              <h3 className="mb-2 mt-4 text-xs font-semibold uppercase tracking-wide text-text-muted">
                Kapitelplan (Zielwortzahl)
              </h3>
              <ul className="space-y-1 text-sm">
                {Object.entries(projekt.kapitelplan)
                  .sort(([a], [b]) => Number(a) - Number(b))
                  .map(([n, ziel]) => (
                    <li key={n} className="flex justify-between">
                      <span>Kapitel {n}</span>
                      <span className="text-text-muted">{ziel} Woerter</span>
                    </li>
                  ))}
              </ul>
            </>
          )}
        </div>
        </CollapsibleCard>

        <CollapsibleCard
          title="🚫 verbotsliste.md"
          defaultOffen={false}
          aktionen={
            <>
              {verbotslisteHinweis && <span className="text-xs text-accent-light">{verbotslisteHinweis}</span>}
              <Button onClick={verbotslisteSpeichern} disabled={verbotslisteWirdGespeichert}>
                {verbotslisteWirdGespeichert ? "Speichert..." : "Speichern"}
              </Button>
            </>
          }
        >
          <Editor
            height="clamp(220px, 40vh, 320px)"
            defaultLanguage="markdown"
            value={verbotslisteInhalt}
            onChange={(v) => setVerbotslisteInhalt(v ?? "")}
            theme="vs-dark"
            options={{ wordWrap: "on", minimap: { enabled: false }, fontSize: 13 }}
          />
        </CollapsibleCard>

        <CollapsibleCard
          title="✍️ stilproben.md"
          defaultOffen={false}
          aktionen={
            <>
              {stilprobenHinweis && <span className="text-xs text-accent-light">{stilprobenHinweis}</span>}
              <Button onClick={stilprobenSpeichern} disabled={stilprobenWirdGespeichert}>
                {stilprobenWirdGespeichert ? "Speichert..." : "Speichern"}
              </Button>
            </>
          }
        >
          <p className="mb-3 text-sm text-text-muted">
            Optional: ein bis drei kurze Ausschnitte (je etwa 100 bis 300 Wörter) aus Geschichten, deren Sprache,
            Satzrhythmus und Ton dir gefallen haben. Der Autor orientiert sich beim Schreiben daran, übernimmt aber
            NICHT die Handlung, Namen oder Figuren daraus. Leer lassen hat keinen Effekt.
          </p>
          <Editor
            height="clamp(220px, 40vh, 320px)"
            defaultLanguage="markdown"
            value={stilprobenInhalt}
            onChange={(v) => setStilprobenInhalt(v ?? "")}
            theme="vs-dark"
            options={{ wordWrap: "on", minimap: { enabled: false }, fontSize: 13 }}
          />
        </CollapsibleCard>

        {architektenGespraech && (
          <CollapsibleCard title="📜 Architekten-Gespräch" defaultOffen={false}>
            <pre className="max-h-[400px] overflow-auto whitespace-pre-wrap p-4 text-sm text-text">
              {architektenGespraech}
            </pre>
          </CollapsibleCard>
        )}
      </div>
    </div>

    {zuruecksetzenOffen && (
      <ConfirmDialog
        titel="Geschichte zurücksetzen?"
        beschreibung={
          `Alle bisher geschriebenen Kapitel, Prüf-Ergebnisse, Zwischenstände, ` +
          `Automatik-Verläufe und Sicherungsdateien von "${projekt?.ordner ?? ordner}" werden ` +
          `gelöscht - erhalten bleibt NUR das Gerüst (mit Verbotsliste, Ausgangslage und Personas). ` +
          `Es wird KEINE Kopie angelegt, die bestehende Geschichte wird überschrieben. ` +
          `Das lässt sich nicht rückgängig machen.` +
          (aktionsFehler ? `\n\nFehler: ${aktionsFehler}` : "")
        }
        bestaetigenText="Zurücksetzen"
        wirdAusgefuehrt={wirdZurueckgesetzt}
        onBestaetigen={zuruecksetzenBestaetigt}
        onAbbrechen={() => setZuruecksetzenOffen(false)}
      />
    )}

    {kiOverlay && (
      <KiGeruestOverlay
        ordner={ordner}
        epocheAnzeigename={(projekt?.epoche ?? "").replace(/-/g, " ")}
        epoche={projekt?.epoche}
        fundusFiguren={fundusFiguren}
        sshZielId={sshZielId}
        startphase={kiOverlay}
        onGestartet={() => setKiLaufToken((t) => t + 1)}
        onFertig={() => kiEntwurfAbgeschlossen(ordner)}
        onAbbrechen={() => setKiOverlay(null)}
      />
    )}

    {umbenennenOffen && (
      <OrdnerUmbenennenDialog
        aktuellerName={aktuellerOrdnerName}
        wirdAusgefuehrt={wirdUmbenannt}
        fehler={umbenennenFehler}
        onUmbenennen={ordnerUmbenennen}
        onAbbrechen={() => setUmbenennenOffen(false)}
      />
    )}
    </>
  );
}
